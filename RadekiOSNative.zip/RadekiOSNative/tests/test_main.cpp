#include <cstdio>
#include <random>

#include "arm64/arm64.h"
#include "binary_analysis/analysis.h"
#include "core/json.h"
#include "mach_o/macho.h"
#include "mini_a64.h"
#include "relinker/relinker.h"
#include "runtime/runtime.h"
#include "synth_macho.h"

using namespace radeki;
static int failures = 0, checks = 0;
#define CHECK(c) do { ++checks; if (!(c)) { ++failures; printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #c); } } while (0)
#define THROWS(e, ex) do { ++checks; bool t = false; try { ex; } catch (const e&) { t = true; } if (!t) { ++failures; printf("FAIL %s:%d: expected %s\n", __FILE__, __LINE__, #e); } } while (0)
#define TEST(n) static void n()

TEST(bytes_bounds) {
  uint8_t d[4] = {1, 2, 3, 4};
  Reader r(Bytes(d, 4));
  CHECK(r.read<uint32_t>(0) == 0x04030201);
  THROWS(FormatError, r.read<uint32_t>(1));
  THROWS(FormatError, r.read<uint8_t>(UINT64_MAX));
  uint8_t u[3] = {0xE5, 0x8E, 0x26};
  Reader u2(Bytes(u, 3)); uint64_t o = 0;
  CHECK(u2.uleb(o, 3, "t") == 624485);
  uint8_t bad[2] = {0x80, 0x80}; Reader b2(Bytes(bad, 2)); o = 0;
  THROWS(FormatError, b2.uleb(o, 2, "t"));
  uint8_t sl[1] = {0x7F}; Reader s1(Bytes(sl, 1)); o = 0;
  CHECK(s1.sleb(o, 1, "t") == -1);
}

TEST(arm64_encodings) {
  using namespace a64;
  CHECK(decode(0x94000002).kind == Kind::BL && decode(0x94000002).imm == 8);
  CHECK(decode(0x17FFFFFF).kind == Kind::B && decode(0x17FFFFFF).imm == -4);
  CHECK(decode(0xD65F03C0).kind == Kind::RET);
  CHECK(decode(0xD63F0100).kind == Kind::BLR);
  CHECK(decode(0xD4200020).kind == Kind::BRK && decode(0xD4200020).brk == 1);
  CHECK(decode(0xD503233F).kind == Kind::PacSign);   // paciasp
  CHECK(decode(0xD50323BF).kind == Kind::PacAuth);   // autiasp
  CHECK(decode(0xD65F0BFF).kind == Kind::PacAuth);   // retaa
  CHECK(decode(0xD503201F).kind == Kind::Other);     // nop
  auto w = withTarget(0x90000000, 0x100001008, 0x100005000);
  CHECK(w && targetOf(decode(*w), 0x100001008) == 0x100005000);
  CHECK(!withTarget(0x90000000, 0, 1ull << 40));      // ADRP out of range
  CHECK(!encodeB(0, 1ull << 28, false));              // B out of range
  CHECK(!encodeB(0, 2, false));                       // misaligned
  auto adr = withTarget(0x10000001, 0x1000, 0x1ABC);
  CHECK(adr && targetOf(decode(*adr), 0x1000) == 0x1ABC && (*adr & 31) == 1);
  auto ldr = withTarget(0x58000003, 0x1000, 0x1100);
  CHECK(ldr && targetOf(decode(*ldr), 0x1000) == 0x1100);
}

TEST(fat_and_selection) {
  auto a = synth::build();
  auto f = synth::fat({{{0x0100000C, 0}, a}, {{12, 9}, a}});
  auto sl = macho::listSlices(f);
  CHECK(sl.size() == 2 && sl[0].arch == macho::Arch::ARM64 && sl[1].arch == macho::Arch::ARMv7);
  auto ch = macho::chooseSlice(sl);
  CHECK(ch.index && *ch.index == 0);
  auto only32 = macho::chooseSlice({sl[1]});
  CHECK(only32.index && *only32.index == 0);
  auto x86 = macho::chooseSlice({macho::SliceInfo{macho::Arch::X86_64, 0x01000007, 3, 0, 0, true, false}});
  CHECK(!x86.index && x86.reason.find("x86_64") != std::string::npos);
  auto fe = synth::fat({{{0x0100000C, 2}, a}});
  CHECK(macho::listSlices(fe)[0].arch == macho::Arch::ARM64e);
  fe[4 + 3] = 0;  // zero archs
  THROWS(FormatError, macho::listSlices(fe));
  uint8_t junk[16] = {0xCA, 0xFE, 0xBA, 0xBE, 0, 0, 0, 0x55};
  THROWS(FormatError, macho::listSlices(Bytes(junk, 16)));
}

TEST(parse_dyld_info) {
  auto f = synth::build();
  auto img = macho::parseFile(f);
  CHECK(img.arch == macho::Arch::ARM64 && img.is64 && img.segments.size() == 4);
  CHECK(img.entry && *img.entry == synth::kText);
  CHECK(img.dylibs.size() == 1 && img.dylibs[0].name == "/usr/lib/libSystem.B.dylib");
  CHECK(img.imports.size() == 2 && img.imports[0].name == "_puts" && img.imports[1].name == "_missing_fn");
  CHECK(img.fixups.size() == 3);
  size_t rebases = 0, binds = 0;
  for (auto& x : img.fixups) { (x.kind == macho::Fixup::Kind::Rebase ? rebases : binds)++; }
  CHECK(rebases == 1 && binds == 2);
  CHECK(img.functionStarts.size() == 2 && img.functionStarts[1] == synth::kText + 60);
  CHECK(img.symbols.size() == 4 && img.symbols[2].undefined());
  CHECK(img.uuid.rfind("A0A1A2A3", 0) == 0);
}

TEST(parse_chained) {
  for (int fmt : {2, 6}) {
    auto f = synth::build({fmt});
    auto img = macho::parseFile(f);
    CHECK(img.hasChainedFixups && img.fixups.size() == 3 && img.imports.size() == 2);
    CHECK(img.fixups[2].kind == macho::Fixup::Kind::Rebase && img.fixups[2].target == synth::kStr);
    CHECK(img.fixups[0].kind == macho::Fixup::Kind::Bind && img.imports[img.fixups[0].importIndex].name == "_puts");
    CHECK(img.fixups[1].addr == synth::kData + 8);
  }
  auto eb = synth::build({9, 2});
  auto e = macho::parseFile(eb);
  CHECK(e.arch == macho::Arch::ARM64e && e.fixups.size() == 3 && e.fixups[2].auth && e.fixups[2].diversity == 0x1234);
}

TEST(malformed_inputs) {
  auto good = synth::build();
  auto trunc = good; trunc.resize(40);
  THROWS(FormatError, macho::parseFile(trunc));
  auto m = good; m[16] = 0xFF; m[17] = 0xFF;  // absurd ncmds
  THROWS(FormatError, macho::parseFile(m));
  m = good; m[20] = 0xFF; m[21] = 0xFF; m[22] = 0xFF;  // sizeofcmds beyond file
  THROWS(FormatError, macho::parseFile(m));
  m = good; m[36] = 3;  // cmdsize of first command (PAGEZERO) -> misaligned/short
  THROWS(FormatError, macho::parseFile(m));
  m = good; m[0] = 0;
  THROWS(FormatError, macho::parseFile(m));
}

TEST(analysis_report) {
  auto f = synth::build();
  auto img = macho::parseFile(f);
  auto rep = analysis::analyze(img);
  CHECK(rep.instructions == 17 && rep.indirectBranches == 2 && rep.returns == 2);
  CHECK(rep.functions.size() == 2 && rep.functions[0].name == "_main" && rep.functions[1].name == "_helper");
  CHECK(rep.functions[0].size == 60 && rep.functions[1].size == 8);
  bool call = false, strRef = false;
  for (auto& x : rep.xrefs) {
    if (x.kind == analysis::XrefKind::Call && x.to == synth::kText + 60) call = true;
    if (x.kind == analysis::XrefKind::AdrpPair && x.to == synth::kStr) strRef = true;
  }
  CHECK(call && strRef);
  CHECK(rep.blockers.empty());
}

TEST(link_and_execute) {
  for (int fmt : {0, 2, 6}) {
    auto f = synth::build({fmt});
    auto img = macho::parseFile(f);
    relinker::CompatRegistry reg;
    reg.add("_puts", 0x300000000ull);
    relinker::LinkOptions opt;
    opt.loadBase = 0x240000000ull;  // different slide than the file's base
    opt.resolver = &reg;
    auto li = relinker::link(img, opt);
    CHECK(li.slide == 0x140000000ull && li.rebases == 1 && li.binds == 2);
    CHECK(li.read64(0x240004010) == 0x240002010);          // rebased pointer
    CHECK(li.read64(0x240004000) == 0x300000000ull);       // bound compat import
    CHECK(li.traps.size() == 1 && li.traps[0].symbol == "_missing_fn");
    CHECK(li.read64(0x240004008) == li.traps[0].addr);     // unresolved -> trap, not fake success
    CHECK(li.read32(li.traps[0].addr) == 0xD4200000);
    auto v = relinker::validate(li);
    CHECK(v.ok() && v.checked > 0);

    MiniCpu cpu; cpu.img = &li;
    cpu.hooks[0x300000000ull] = [](MiniCpu& c) { c.out += c.cstr(c.x[0]) + "\n"; c.x[0] = 1; };
    int rc = cpu.run(*li.entry);
    CHECK(rc == 7);
    CHECK(cpu.out == "hello radeki\nhello radeki\n");
    CHECK(cpu.trap.empty());
  }
}

TEST(unresolved_import_traps_with_symbol) {
  auto f = synth::build();
  auto img = macho::parseFile(f);
  auto li = relinker::link(img, {});  // no compat library at all
  CHECK(li.traps.size() == 2);
  MiniCpu cpu; cpu.img = &li;
  CHECK(cpu.run(*li.entry) == -1);
  CHECK(cpu.trap == "_puts");  // first call hits the BRK stub named after the symbol
}

TEST(link_refusals) {
  auto encb = synth::build({0, 0, 1});
  auto enc = macho::parseFile(encb);
  CHECK(enc.cryptId == 1);
  THROWS(relinker::LinkError, relinker::link(enc, {}));
  CHECK(!analysis::analyze(enc).blockers.empty());
  auto eb = synth::build({9, 2});
  auto e = macho::parseFile(eb);
  THROWS(relinker::LinkError, relinker::link(e, {}));
  auto f = synth::build(); auto img = macho::parseFile(f);
  relinker::LinkOptions o; o.loadBase = 0x1000;
  THROWS(relinker::LinkError, relinker::link(img, o));
  img.arch = macho::Arch::ARMv7;
  THROWS(relinker::LinkError, relinker::link(img, {}));
}

TEST(branch_veneer) {
  auto f = synth::build(); auto img = macho::parseFile(f);
  auto li = relinker::link(img, {});
  uint64_t site = li.loadBase + 0x1000 + 7 * 4;  // the bl helper
  uint64_t near = li.loadBase + 0x1000 + 15 * 4;
  relinker::patchBranch(li, site, near + 4, true);
  CHECK(li.veneerCount == 0 && a64::targetOf(a64::decode(li.read32(site)), site) == near + 4);
  uint64_t far = 0x7000000000ull;  // beyond +-128MB
  relinker::patchBranch(li, site, far, true);
  CHECK(li.veneerCount == 1);
  uint64_t vtarget = a64::targetOf(a64::decode(li.read32(site)), site);
  CHECK(vtarget == li.veneerBase && li.read64(vtarget + 8) == far);
  THROWS(relinker::LinkError, relinker::patchBranch(li, li.loadBase + 0x4000, far, false));  // data segment
  CHECK(relinker::validate(li).ok());
}

TEST(validator_catches_escape) {
  auto f = synth::build(); auto img = macho::parseFile(f);
  auto li = relinker::link(img, {});
  li.write32(li.loadBase + 0x1000, 0x94000000 | 0x02000000);  // bl -128MB: escapes the image
  auto v = relinker::validate(li);
  CHECK(!v.ok() && v.violations[0].addr == li.loadBase + 0x1000);
}

TEST(mutation_fuzz_no_crash) {
  std::mt19937 rng(12345);
  for (int fmt : {0, 6, 9}) {
    auto base = synth::build({fmt, fmt == 9 ? 2u : 0u});
    for (int it = 0; it < 4000; ++it) {
      auto m = base;
      int n = 1 + rng() % 4;
      for (int k = 0; k < n; ++k) m[(rng() % 3 == 0) ? 0x8000 + rng() % 0x180 : rng() % 0x400] = uint8_t(rng());
      try {
        auto img = macho::parseFile(m);
        analysis::analyze(img);
        relinker::LinkOptions o; o.maxImageBytes = 64ull << 20;
        auto li = relinker::link(img, o);
        relinker::validate(li);
      } catch (const FormatError&) {} catch (const relinker::LinkError&) {}
    }
  }
  CHECK(true);
}

TEST(compat_and_runtime) {
  auto reg = runtime::makeCompatRegistry();
  CHECK(reg.resolve("_puts", "") && reg.resolve("_malloc", "") && reg.resolve("___stack_chk_guard", ""));
  CHECK(!reg.resolve("_UIApplicationMain", ""));
  using PutsFn = int (*)(const char*);
  auto puts = reinterpret_cast<PutsFn>(*reg.resolve("_puts", ""));
  runtime::takeGuestOutput();
  puts("hi");
  CHECK(runtime::takeGuestOutput() == "hi\n");
  auto f = synth::build(); auto img = macho::parseFile(f);
  auto r = runtime::runImage(img);
#if defined(__aarch64__)
  CHECK(r.ran && r.exitCode == 7 && r.output == "hello radeki\nhello radeki\n");
#else
  CHECK(!r.ran && r.error.find("ARM64 host") != std::string::npos);  // honest on non-ARM64 hosts
#endif
  auto tb = synth::build({0, 0, 0}); auto timg = macho::parseFile(tb); timg.hasTLS = true;
  CHECK(runtime::runImage(timg).error.find("thread-local") != std::string::npos);
}

TEST(json_writer) {
  JsonWriter j;
  j.beginObject().kv("a", "x\"y").key("l").beginArray().num(1).num(-2).endArray().kvh("h", 255).kvb("b", true).endObject();
  CHECK(j.str() == R"({"a":"x\"y","l":[1,-2],"h":"0xff","b":true})");
}

int main() {
  bytes_bounds(); arm64_encodings(); fat_and_selection(); parse_dyld_info(); parse_chained(); malformed_inputs();
  analysis_report(); link_and_execute(); unresolved_import_traps_with_symbol(); link_refusals(); branch_veneer();
  validator_catches_escape(); compat_and_runtime(); mutation_fuzz_no_crash(); json_writer();
  printf("%d checks, %d failures\n", checks, failures);
  return failures ? 1 : 0;
}
