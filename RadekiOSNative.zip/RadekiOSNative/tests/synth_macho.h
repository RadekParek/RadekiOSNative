// Builds small, legal, synthetic ARM64 Mach-O files for tests (no Apple code involved).
#pragma once
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

#include "arm64/arm64.h"

namespace synth {
using Buf = std::vector<uint8_t>;
struct Opts {
  int chainedFmt = 0;        // 0 = dyld-info opcodes, else chained pointer format (2, 6, 9)
  uint32_t cpusub = 0;       // 2 => arm64e
  uint32_t cryptid = 0;
};
constexpr uint64_t kBase = 0x100000000ull, kText = kBase + 0x1000, kStr = kBase + 0x2010, kData = kBase + 0x4000;
constexpr int kHelperIdx = 15;

inline void p32(Buf& b, size_t o, uint32_t v) { std::memcpy(&b[o], &v, 4); }
inline void p64(Buf& b, size_t o, uint64_t v) { std::memcpy(&b[o], &v, 8); }
inline void put(Buf& c, uint32_t v) { c.insert(c.end(), (uint8_t*)&v, (uint8_t*)&v + 4); }
inline void put64(Buf& c, uint64_t v) { c.insert(c.end(), (uint8_t*)&v, (uint8_t*)&v + 8); }
inline void putName(Buf& c, const char* n) { char t[16] = {}; std::strncpy(t, n, 16); c.insert(c.end(), t, t + 16); }
inline void pad(Buf& c, size_t n) { while (c.size() % n) c.push_back(0); }

inline std::vector<uint32_t> code() {
  using namespace radeki::a64;
  auto adrp = [](int rd, uint64_t pc, uint64_t tgt) { return *withTarget(0x90000000u | rd, pc, tgt); };
  uint64_t t = kText;
  std::vector<uint32_t> c = {
      0xA9BF7BFD, 0x910003FD,
      adrp(0, t + 8, kStr), 0x91000000u | (0x10 << 10),                 // adrp x0,str ; add x0,x0,#0x10
      adrp(8, t + 16, kData), 0xF9400108,                               // adrp x8,got ; ldr x8,[x8]
      0xD63F0100,                                                       // blr x8
      *encodeB(t + 28, t + kHelperIdx * 4, true),                       // bl helper
      adrp(1, t + 32, kData), 0xF9400820, 0xF9400028, 0xD63F0100,       // x1=data; ldr x0,[x1,#0x10]; ldr x8,[x1]; blr x8
      0x528000E0,                                                       // mov w0,#7
      0xA8C17BFD, 0xD65F03C0,                                           // ldp ; ret
      0x52800000, 0xD65F03C0};                                          // helper: mov w0,#0 ; ret
  return c;
}

inline Buf build(const Opts& o = {}) {
  Buf f(0x8180, 0);
  auto c = code();
  for (size_t i = 0; i < c.size(); ++i) p32(f, 0x1000 + i * 4, c[i]);
  std::strcpy((char*)&f[0x2010], "hello radeki");
  const size_t le = 0x8000;
  Buf rebase = {0x11, 0x22, 0x10, 0x51, 0x00};
  Buf bind = {0x11, 0x40, '_', 'p', 'u', 't', 's', 0, 0x51, 0x72, 0x00, 0x90,
              0x40, '_', 'm', 'i', 's', 's', 'i', 'n', 'g', '_', 'f', 'n', 0, 0x72, 0x08, 0x90, 0x00};
  Buf fstarts = {0x80, 0x20, 0x3C, 0x00};  // 0x1000, +60
  std::memcpy(&f[le + 0x00], rebase.data(), rebase.size());
  std::memcpy(&f[le + 0x20], bind.data(), bind.size());
  std::memcpy(&f[le + 0x60], fstarts.data(), fstarts.size());
  uint32_t chainedSize = 0;
  if (o.chainedFmt) {
    Buf b(112, 0);
    p32(b, 4, 32); p32(b, 8, 80); p32(b, 12, 88); p32(b, 16, 2); p32(b, 20, 1); p32(b, 24, 0);
    p32(b, 32, 4); p32(b, 32 + 4 + 2 * 4, 24);
    p32(b, 56, 24); b[60] = 0x00; b[61] = 0x40; b[62] = o.chainedFmt; b[63] = 0;
    p64(b, 64, 0x4000); b[76] = 1;
    p32(b, 80, 1 | (1u << 9)); p32(b, 84, 1 | (7u << 9));
    std::memcpy(&b[89], "_puts", 6); std::memcpy(&b[95], "_missing_fn", 12);
    std::memcpy(&f[le + 0x80], b.data(), b.size());
    chainedSize = 112;
    uint64_t s0, s1, s2;
    if (o.chainedFmt == 9) {
      s0 = 0 | (1ull << 51) | (1ull << 62); s1 = 1 | (1ull << 51) | (1ull << 62);
      s2 = 0x2010ull | (0x1234ull << 32) | (1ull << 63);
    } else {
      s0 = 0 | (2ull << 51) | (1ull << 63); s1 = 1 | (2ull << 51) | (1ull << 63);
      s2 = o.chainedFmt == 6 ? 0x2010ull : kStr;
    }
    p64(f, 0x4000, s0); p64(f, 0x4008, s1); p64(f, 0x4010, s2);
  } else {
    p64(f, 0x4010, kStr);  // pointer stored as unslid vmaddr; rebase opcodes mark it
  }
  // symtab: strtab "\0_helper\0_main\0_puts\0_missing_fn\0"
  const char strtab[] = "\0_helper\0_main\0_puts\0_missing_fn";
  std::memcpy(&f[le + 0x140], strtab, sizeof strtab);
  struct N { uint32_t x; uint8_t t, s; uint16_t d; uint64_t v; };
  N syms[4] = {{1, 0x0E, 1, 0, kText + kHelperIdx * 4}, {9, 0x0F, 1, 0, kText}, {15, 0x01, 0, 0x100, 0}, {21, 0x01, 0, 0x100, 0}};
  std::memcpy(&f[le + 0x100], syms, sizeof syms);

  Buf lc;
  auto seg = [&](const char* n, uint64_t va, uint64_t vs, uint64_t fo, uint64_t fs, uint32_t prot, uint32_t nsect) {
    put(lc, 0x19); put(lc, 72 + 80 * nsect); putName(lc, n);
    put64(lc, va); put64(lc, vs); put64(lc, fo); put64(lc, fs);
    put(lc, prot); put(lc, prot); put(lc, nsect); put(lc, 0);
  };
  auto sect = [&](const char* n, const char* sg, uint64_t a, uint64_t sz, uint32_t off, uint32_t fl) {
    putName(lc, n); putName(lc, sg); put64(lc, a); put64(lc, sz);
    put(lc, off); put(lc, 2); put(lc, 0); put(lc, 0); put(lc, fl); put(lc, 0); put(lc, 0); put(lc, 0);
  };
  seg("__PAGEZERO", 0, kBase, 0, 0, 0, 0);
  seg("__TEXT", kBase, 0x4000, 0, 0x4000, 5, 2);
  sect("__text", "__TEXT", kText, c.size() * 4, 0x1000, 0x80000400);
  sect("__cstring", "__TEXT", kStr, 16, 0x2010, 2);
  seg("__DATA", kData, 0x4000, 0x4000, 0x4000, 3, 2);
  sect("__got", "__DATA", kData, 16, 0x4000, 6);
  sect("__data", "__DATA", kData + 0x10, 8, 0x4010, 0);
  seg("__LINKEDIT", kBase + 0x8000, 0x4000, le, 0x180, 1, 0);
  uint32_t ncmds = 4 + 1 + 1 + 1 + 1 + 1 + 1 + 1;  // 4 segs + fixups + symtab + dysymtab + dylib + main + uuid + fstarts
  if (o.chainedFmt) { put(lc, 0x80000034); put(lc, 16); put(lc, le + 0x80); put(lc, chainedSize); }
  else {
    put(lc, 0x80000022); put(lc, 48);
    uint32_t v[10] = {le, 5, le + 0x20, 29, 0, 0, 0, 0, 0, 0};
    for (uint32_t x : v) put(lc, x);
  }
  put(lc, 2); put(lc, 24); put(lc, le + 0x100); put(lc, 4); put(lc, le + 0x140); put(lc, sizeof strtab);
  put(lc, 0xB); put(lc, 80);
  uint32_t dy[18] = {0, 1, 1, 1, 2, 2};
  for (uint32_t x : dy) put(lc, x);
  const char* ln = "/usr/lib/libSystem.B.dylib";
  put(lc, 0xC); put(lc, 56); put(lc, 24); put(lc, 0); put(lc, 0x10000); put(lc, 0x10000);
  size_t s0 = lc.size(); lc.insert(lc.end(), ln, ln + std::strlen(ln) + 1); lc.resize(s0 + 32);
  put(lc, 0x80000028); put(lc, 24); put64(lc, 0x1000); put64(lc, 0);
  put(lc, 0x1B); put(lc, 24); for (int i = 0; i < 16; ++i) lc.push_back(uint8_t(0xA0 + i));
  put(lc, 0x26); put(lc, 16); put(lc, le + 0x60); put(lc, 4);
  if (o.cryptid) { put(lc, 0x2C); put(lc, 24); put(lc, 0x1000); put(lc, 0x1000); put(lc, o.cryptid); put(lc, 0); ++ncmds; }

  p32(f, 0, 0xFEEDFACF); p32(f, 4, 0x0100000C); p32(f, 8, o.cpusub); p32(f, 12, 2);
  p32(f, 16, ncmds); p32(f, 20, (uint32_t)lc.size()); p32(f, 24, 0x200085); p32(f, 28, 0);
  std::memcpy(&f[32], lc.data(), lc.size());
  return f;
}

// Wrap slices in a fat container (big-endian header).
inline Buf fat(const std::vector<std::pair<std::pair<uint32_t, uint32_t>, Buf>>& slices) {
  Buf out(8 + 20 * slices.size(), 0);
  auto be = [&](size_t o, uint32_t v) { v = __builtin_bswap32(v); std::memcpy(&out[o], &v, 4); };
  be(0, 0xCAFEBABE); be(4, (uint32_t)slices.size());
  for (size_t i = 0; i < slices.size(); ++i) {
    while (out.size() % 0x4000) out.push_back(0);
    size_t off = out.size();
    out.insert(out.end(), slices[i].second.begin(), slices[i].second.end());
    size_t e = 8 + 20 * i;
    be(e, slices[i].first.first); be(e + 4, slices[i].first.second); be(e + 8, (uint32_t)off);
    be(e + 12, (uint32_t)slices[i].second.size()); be(e + 16, 14);
  }
  return out;
}
}  // namespace synth
