package org.radekiosnative.recompiler;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Persistent library: a corrupt file is preserved as .bad and never silently read as valid. */
public final class Library {
    private final File file;
    private final List<JSONObject> entries = new ArrayList<>();
    public Library(Context context) {
        file = new File(context.getFilesDir(), "library.json");
        if (!file.exists()) return;
        try (FileInputStream in = new FileInputStream(file)) {
            byte[] bytes = new byte[(int)Math.min(file.length(), 8 * 1024 * 1024)];
            if (in.read(bytes) != bytes.length || file.length() > bytes.length) throw new Exception("truncated library");
            JSONArray list = new JSONArray(new String(bytes, StandardCharsets.UTF_8));
            for (int i = 0; i < list.length(); i++) entries.add(list.getJSONObject(i));
        } catch (Exception e) {
            entries.clear();
            File bad = new File(file.getParentFile(), "library.json.bad");
            if (bad.exists()) bad.delete();
            file.renameTo(bad);
        }
    }
    public synchronized List<JSONObject> entries() { return new ArrayList<>(entries); }
    public synchronized void upsert(JSONObject item) throws Exception {
        String id = item.getString("bundleId"), version = item.getString("version");
        if (id.isEmpty()) throw new Exception("missing bundle ID");
        for (int i=0;i<entries.size();i++) if (id.equals(entries.get(i).optString("bundleId")) &&
                version.equals(entries.get(i).optString("version"))) { entries.set(i,item);save();return; }
        // Bundles live at games/<bundleId>/bundle; do not retain stale cards after an upgrade.
        entries.removeIf(old -> id.equals(old.optString("bundleId")));
        entries.add(item);save();
    }
    private void save() throws Exception {
        JSONArray list = new JSONArray();for (JSONObject e:entries) list.put(e);
        File tmp = new File(file.getParentFile(), "library.json.tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(list.toString().getBytes(StandardCharsets.UTF_8));out.getFD().sync();
        }
        if (!tmp.renameTo(file)) {
            if (!file.delete() || !tmp.renameTo(file)) throw new Exception("could not save library");
        }
    }
}
