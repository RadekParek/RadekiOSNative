package org.radekiosnative.recompiler;

public class Native {
    static { System.loadLibrary("radekijni"); }
    public static native String analyze(String path);
    public static native String run(String path, boolean compatibilityFallbacks, boolean traceMissingApis);
    public static native String selfTest();
    public static native String inspectBundle(String appPath, String iconPath);
}
