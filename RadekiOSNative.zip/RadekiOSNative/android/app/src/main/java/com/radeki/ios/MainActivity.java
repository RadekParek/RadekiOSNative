package com.radeki.ios;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class MainActivity extends Activity {
    private static final int PICK = 1;
    private final List<File> games = new ArrayList<>();
    private BaseAdapter adapter;

    private File dir() { File d = new File(getFilesDir(), "games"); d.mkdirs(); return d; }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 96, 32, 32);
        TextView title = new TextView(this);
        title.setText("RadekiOSNative");
        title.setTextSize(24);
        root.addView(title);
        Button add = new Button(this);
        add.setText("Add game (.ipa)");
        add.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, PICK);
        });
        root.addView(add);
        Button self = new Button(this);
        self.setText("Run built-in ARM64 self-test");
        self.setOnClickListener(v -> launch(null, "Self-test"));
        root.addView(self);
        GridView grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setVerticalSpacing(24);
        adapter = new BaseAdapter() {
            public int getCount() { return games.size(); }
            public Object getItem(int i) { return games.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View cv, ViewGroup p) {
                File g = games.get(i);
                LinearLayout t = new LinearLayout(MainActivity.this);
                t.setOrientation(LinearLayout.VERTICAL);
                t.setGravity(Gravity.CENTER_HORIZONTAL);
                ImageView iv = new ImageView(MainActivity.this);
                iv.setLayoutParams(new LinearLayout.LayoutParams(200, 200));
                Bitmap bm = BitmapFactory.decodeFile(new File(g, "icon.png").getPath());
                if (bm != null) iv.setImageBitmap(bm); else iv.setBackgroundColor(Color.LTGRAY);
                TextView tv = new TextView(MainActivity.this);
                tv.setText(g.getName());
                tv.setGravity(Gravity.CENTER);
                t.addView(iv);
                t.addView(tv);
                return t;
            }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, i, id) -> open(games.get(i)));
        grid.setOnItemLongClickListener((p, v, i, id) -> {
            new AlertDialog.Builder(this).setMessage("Remove " + games.get(i).getName() + "?")
                .setPositiveButton("Remove", (d, w) -> { delete(games.get(i)); refresh(); })
                .setNegativeButton("Cancel", null).show();
            return true;
        });
        root.addView(grid);
        setContentView(root);
        refresh();
    }

    private void refresh() {
        games.clear();
        File[] fs = dir().listFiles();
        if (fs != null) for (File f : fs) if (f.isDirectory()) games.add(f);
        Collections.sort(games);
        adapter.notifyDataSetChanged();
    }

    private void delete(File f) {
        File[] c = f.listFiles();
        if (c != null) for (File x : c) delete(x);
        f.delete();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req != PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        Toast.makeText(this, "Importing...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String msg;
            try { msg = "Added " + importIpa(uri); }
            catch (Exception e) { msg = "Import failed: " + e.getMessage(); }
            final String m = msg;
            runOnUiThread(() -> { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); refresh(); });
        }).start();
    }

    // Copies the IPA, extracts the main executable and the largest icon PNG.
    private String importIpa(Uri uri) throws Exception {
        File tmp = new File(getCacheDir(), "import.ipa");
        try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(tmp)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        try (ZipFile zip = new ZipFile(tmp)) {
            String appDir = null;
            for (Enumeration<? extends ZipEntry> e = zip.entries(); e.hasMoreElements();) {
                String n = e.nextElement().getName();
                if (n.startsWith("Payload/") && n.indexOf(".app/") > 0) { appDir = n.substring(0, n.indexOf(".app/") + 5); break; }
            }
            if (appDir == null) throw new Exception("not an iOS .ipa (no Payload/*.app)");
            String name = appDir.substring(8, appDir.length() - 5);
            ZipEntry exec = zip.getEntry(appDir + name);
            ZipEntry icon = null;
            for (Enumeration<? extends ZipEntry> e = zip.entries(); e.hasMoreElements();) {
                ZipEntry z = e.nextElement();
                String rel = z.getName().startsWith(appDir) ? z.getName().substring(appDir.length()) : null;
                if (rel == null || rel.contains("/") || z.isDirectory()) continue;
                if (exec == null && !rel.contains(".") && (exec == null || z.getSize() > exec.getSize())) exec = z;
                if (rel.toLowerCase().endsWith(".png") && rel.toLowerCase().contains("icon") && (icon == null || z.getSize() > icon.getSize())) icon = z;
            }
            if (exec == null) throw new Exception("main executable not found in .ipa");
            File g = new File(dir(), name);
            g.mkdirs();
            copy(zip, exec, new File(g, "executable.bin"));
            if (icon != null) copy(zip, icon, new File(g, "icon.png"));
            tmp.delete();
            return name;
        }
    }

    private void copy(ZipFile zip, ZipEntry e, File to) throws Exception {
        try (InputStream in = zip.getInputStream(e); OutputStream out = new FileOutputStream(to)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    private void open(File g) {
        new Thread(() -> {
            String text;
            try {
                JSONObject j = new JSONObject(Native.analyze(new File(g, "executable.bin").getPath()));
                StringBuilder s = new StringBuilder();
                if (j.has("error")) s.append("Cannot read this game: ").append(j.getString("error")).append("\n");
                else {
                    s.append("Architecture: ").append(j.getString("arch")).append("\n");
                    s.append("Encrypted (App Store DRM): ").append(j.getBoolean("encrypted") ? "yes" : "no").append("\n");
                    s.append("Objective-C: ").append(j.getBoolean("objc")).append("   Swift: ").append(j.getBoolean("swift")).append("\n");
                    s.append("OpenGL ES: ").append(j.getBoolean("opengles")).append("   Metal: ").append(j.getBoolean("metal")).append("\n");
                    s.append("Imported functions: ").append(j.getInt("imports")).append("\n");
                    if (j.getBoolean("linked")) s.append("Relink: OK, unresolved imports: ").append(j.getInt("unresolvedImports")).append("\n");
                    else s.append("Relink failed: ").append(j.optString("linkError")).append("\n");
                    JSONArray bl = j.getJSONArray("blockers");
                    for (int i = 0; i < bl.length(); i++) s.append("Blocker: ").append(bl.getString(i)).append("\n");
                }
                s.append("\nCannot launch yet: the runtime, Objective-C, graphics, audio and input layers are not built.");
                text = s.toString();
            } catch (Throwable t) { text = "Analysis failed: " + t; }
            final String m = text;
            runOnUiThread(() -> new AlertDialog.Builder(this).setTitle(g.getName()).setMessage(m).setPositiveButton("OK", null)
                .setNeutralButton("Launch", (d, w) -> launch(new File(g, "executable.bin").getPath(), g.getName())).show());
        }).start();
    }

    // Starts the guest process and waits for its result file.
    private void launch(String path, String title) {
        final File res = new File(getFilesDir(), "result.json");
        res.delete();
        Intent i = new Intent(this, GuestService.class);
        if (path != null) i.putExtra("path", path);
        startService(i);
        Toast.makeText(this, "Running...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String text = null;
            for (int k = 0; k < 40 && text == null; k++) {
                try { Thread.sleep(500); } catch (InterruptedException e) { break; }
                if (!res.exists()) continue;
                try {
                    java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(res));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    JSONObject j = new JSONObject(sb.toString());
                    StringBuilder s = new StringBuilder();
                    if (j.optBoolean("ran")) s.append("Finished. Exit code: ").append(j.optInt("exitCode")).append("\n");
                    if (j.optBoolean("crashed")) {
                        s.append("Guest crashed: ").append(j.optString("signal")).append(" at ").append(j.optString("faultPc")).append("\n");
                        if (!j.optString("trapSymbol").isEmpty()) s.append("It called an unsupported function: ").append(j.optString("trapSymbol")).append("\n");
                    }
                    if (!j.optString("error").isEmpty()) s.append("Note: ").append(j.optString("error")).append("\n");
                    if (!j.optString("output").isEmpty()) s.append("\nOutput:\n").append(j.optString("output"));
                    text = s.toString();
                } catch (Exception e) { text = "Could not read result: " + e; }
            }
            if (text == null) text = "No result: the guest process died or hung (a crash that could not be caught).";
            final String m = text;
            runOnUiThread(() -> new AlertDialog.Builder(this).setTitle(title).setMessage(m).setPositiveButton("OK", null).show());
        }).start();
    }
}
