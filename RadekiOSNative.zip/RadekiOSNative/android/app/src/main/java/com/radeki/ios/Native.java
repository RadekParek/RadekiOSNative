package com.radeki.ios;

public class Native {
    static { System.loadLibrary("radekijni"); }
    public static native String analyze(String path);
    public static native String run(String path);
    public static native String selfTest();
}
