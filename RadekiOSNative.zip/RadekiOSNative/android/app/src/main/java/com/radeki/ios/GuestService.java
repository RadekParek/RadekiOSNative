package com.radeki.ios;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;

// Runs guest code in a separate process so a guest crash cannot kill the UI.
public class GuestService extends Service {
    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        final String path = i == null ? null : i.getStringExtra("path");
        new Thread(() -> {
            String r;
            try { r = path == null ? Native.selfTest() : Native.run(path); }
            catch (Throwable t) {
                try { r = new JSONObject().put("error", t.toString()).toString(); } catch (Exception e) { r = "{}"; }
            }
            try (FileOutputStream o = new FileOutputStream(new File(getFilesDir(), "result.json"))) {
                o.write(r.getBytes("UTF-8"));
            } catch (Exception e) { /* nothing more we can do */ }
            android.os.Process.killProcess(android.os.Process.myPid());
        }).start();
        return START_NOT_STICKY;
    }
}
