#include <jni.h>

#include <fstream>
#include <iterator>
#include <string>

#include "binary_analysis/analysis.h"
#include "compat/matrix.h"
#include "ipa/bundle.h"
#include "core/json.h"
#include "relinker/relinker.h"
#include "runtime/runtime.h"
#include "synth_macho.h"

using namespace radeki;

static std::string run(const std::string& path) {
  JsonWriter j;
  j.beginObject();
  try {
    std::ifstream f(path, std::ios::binary);
    if (!f) throw FormatError("cannot open extracted executable");
    std::vector<uint8_t> file{std::istreambuf_iterator<char>(f), {}};
    auto slices = macho::listSlices(file);
    auto ch = macho::chooseSlice(slices);
    if (!ch.index) throw FormatError(ch.reason);
    auto img = macho::parseSlice(file, slices[*ch.index]);
    auto rep = analysis::analyze(img);
    j.kv("arch", macho::archName(img.arch)).kvb("encrypted", img.cryptId != 0);
    j.kvb("objc", rep.objc).kvb("swift", rep.swift).kvb("metal", rep.metal).kvb("opengles", rep.gles).kvb("audio", rep.audio);
    j.kvu("imports", img.imports.size());
    j.key("blockers").beginArray();
    for (auto& b : rep.blockers) j.str(b);
    j.endArray();
    compat::Detected detected;
    detected.objc=rep.objc;detected.gles=rep.gles;detected.metal=rep.metal;
    detected.audio=rep.audio;detected.swift=rep.swift;
    for(const auto& f:rep.frameworks){
      if(f.find("UIKit")!=std::string::npos)detected.uikit=true;
      if(f.find("CoreFoundation")!=std::string::npos)detected.corefoundation=true;
      if(f.find("Vulkan")!=std::string::npos)detected.vulkan=true;
    }
    detected.arm64e=img.arch==macho::Arch::ARM64e;
    detected.armv7=img.arch==macho::Arch::ARMv7;
    detected.encrypted=img.cryptId!=0;
    if(detected.encrypted)detected.blockedReason="encrypted executable";
    size_t totalImports=img.imports.size();
    try {
      auto registry = runtime::makeCompatRegistry();
      relinker::LinkOptions o;
      o.resolver = &registry;
      auto li = relinker::link(img, o);
      detected.linked=true;
      // Analysis links without the dispatch-stub factory, so traps and unresolved strong
      // imports coincide; count the imports directly to stay honest if that ever changes.
      size_t strong=0;
      for(const auto& imp:li.imports){
        if(!imp.resolved&&!imp.weak)++strong;
        if(imp.weak&&!imp.resolved)++detected.unresolvedWeak;
      }
      detected.unresolvedStrong=strong;
      j.kvb("linked", true).kvu("unresolvedImports", strong);
    } catch (const relinker::LinkError& e) {
      j.kvb("linked", false).kv("linkError", e.what());
    }
    j.kv("state",compat::runtimeStateName(compat::stateFor(detected)))
      .kv("summary",compat::summaryFor(detected,totalImports));
    j.key("capabilities").beginArray();
    for(const auto& row:compat::neededCapabilities(detected))j.beginObject().kv("id",row.id)
      .kv("title",row.title).kv("status",compat::statusName(row.status)).kv("detail",row.detail).endObject();
    j.endArray();
  } catch (const std::exception& e) {
    j.kv("error", e.what());
  }
  j.endObject();
  return j.str();
}

extern "C" JNIEXPORT jstring JNICALL Java_org_radekiosnative_recompiler_Native_analyze(JNIEnv* env, jclass, jstring path) {
  const char* p = env->GetStringUTFChars(path, nullptr);
  std::string r = run(p);
  env->ReleaseStringUTFChars(path, p);
  return env->NewStringUTF(r.c_str());
}

static std::string resultJson(const runtime::RunResult& r) {
  JsonWriter j;
  j.beginObject().kvb("ran", r.ran).kvb("crashed", r.crashed).key("exitCode").num(r.exitCode);
  j.kv("signal", r.signalName).kv("trapSymbol", r.trapSymbol).kv("error", r.error).kv("output", r.output);
  j.kvh("faultPc", r.faultPc).kvh("faultAddr", r.faultAddr).kv("reason",runtime::describeResult(r))
    .kv("trapClass",r.trapClass).kv("subsystem",r.subsystem).kv("resolutionMethod",r.resolutionMethod)
    .kvh("callAddress",r.callAddress).kv("callSymbol",r.callSymbol).kv("image",r.image)
    .key("threadId").num(r.threadId).kvu("dispatchStubs", r.dispatchStubs);
  j.key("recentCalls").beginArray();for(const auto& c:r.recentCalls)j.str(c);j.endArray();j.endObject();
  return j.str();
}

extern "C" JNIEXPORT jstring JNICALL Java_org_radekiosnative_recompiler_Native_run(JNIEnv* env, jclass, jstring path) {
  const char* p = env->GetStringUTFChars(path, nullptr);
  runtime::RunResult r;
  try {
    std::ifstream f(p, std::ios::binary);
    if (!f) throw FormatError("cannot open extracted executable");
    std::vector<uint8_t> file{std::istreambuf_iterator<char>(f), {}};
    auto slices = macho::listSlices(file);
    auto ch = macho::chooseSlice(slices);
    if (!ch.index) throw FormatError(ch.reason);
    auto img = macho::parseSlice(file, slices[*ch.index]);
    // useStubs=true: framework shims/dummies, libc++ forwarding and logging dispatch stubs
    // replace the BRK traps for unbound imports, so the startup loop can push past them.
    r = runtime::runImage(img, /*useStubs=*/true);
    r.image = p;
  } catch (const std::exception& e) {
    r.error = e.what();
  }
  env->ReleaseStringUTFChars(path, p);
  return env->NewStringUTF(resultJson(r).c_str());
}

// Runs the synthetic ARM64 test program natively on this device.
extern "C" JNIEXPORT jstring JNICALL Java_org_radekiosnative_recompiler_Native_selfTest(JNIEnv* env, jclass) {
  runtime::RunResult r;
  try {
    auto bytes = synth::build({});
    auto img = macho::parseFile(bytes);
    r = runtime::runImage(img);
    r.image = "synthetic self-test";
  } catch (const std::exception& e) {
    r.error = e.what();
  }
  return env->NewStringUTF(resultJson(r).c_str());
}

extern "C" JNIEXPORT jstring JNICALL Java_org_radekiosnative_recompiler_Native_inspectBundle(
    JNIEnv* env,jclass,jstring app,jstring icon) {
  const char* a=env->GetStringUTFChars(app,nullptr);
  const char* dest=env->GetStringUTFChars(icon,nullptr);
  ipa::BundleInfo info;std::string error;
  bool ok=ipa::inspectBundle(a,dest,info,error);
  env->ReleaseStringUTFChars(app,a);env->ReleaseStringUTFChars(icon,dest);
  JsonWriter j;j.beginObject().kvb("ok",ok);
  if(ok){
    j.kv("bundleId",info.bundleIdentifier).kv("name",info.name).kv("version",info.version)
     .kv("shortVersion",info.shortVersion).kv("executable",info.executable)
     .kv("executablePath",info.executablePath).kvu("executableSize",info.executableSize)
     .kv("iconPath",info.iconPath).kv("minimumOSVersion",info.minimumOSVersion).kv("platform",info.platform);
    j.key("architectures").beginArray();for(const auto& arch:info.architectures)j.str(arch);j.endArray();
    j.key("warnings").beginArray();for(const auto& w:info.warnings)j.str(w);j.endArray();
  }else j.kv("error",error);
  j.endObject();return env->NewStringUTF(j.str().c_str());
}
