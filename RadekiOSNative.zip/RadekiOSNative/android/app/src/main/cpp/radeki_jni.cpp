#include <jni.h>

#include <fstream>
#include <iterator>
#include <string>

#include "binary_analysis/analysis.h"
#include "core/json.h"
#include "relinker/relinker.h"
#include "runtime/runtime.h"
#include "synth_macho.h"

using namespace radeki;

static std::string run(const std::string& path) {
  JsonWriter j;
  j.beginObject();
  try {
    std::ifstream f(path, std::ios::binary);
    if (!f) throw FormatError("cannot open extracted executable");
    std::vector<uint8_t> file{std::istreambuf_iterator<char>(f), {}};
    auto slices = macho::listSlices(file);
    auto ch = macho::chooseSlice(slices);
    if (!ch.index) throw FormatError(ch.reason);
    auto img = macho::parseSlice(file, slices[*ch.index]);
    auto rep = analysis::analyze(img);
    j.kv("arch", macho::archName(img.arch)).kvb("encrypted", img.cryptId != 0);
    j.kvb("objc", rep.objc).kvb("swift", rep.swift).kvb("metal", rep.metal).kvb("opengles", rep.gles).kvb("audio", rep.audio);
    j.kvu("imports", img.imports.size());
    j.key("blockers").beginArray();
    for (auto& b : rep.blockers) j.str(b);
    j.endArray();
    try {
      relinker::CompatRegistry none;
      relinker::LinkOptions o;
      o.resolver = &none;
      auto li = relinker::link(img, o);
      j.kvb("linked", true).kvu("unresolvedImports", li.traps.size());
    } catch (const relinker::LinkError& e) {
      j.kvb("linked", false).kv("linkError", e.what());
    }
  } catch (const std::exception& e) {
    j.kv("error", e.what());
  }
  j.endObject();
  return j.str();
}

extern "C" JNIEXPORT jstring JNICALL Java_com_radeki_ios_Native_analyze(JNIEnv* env, jclass, jstring path) {
  const char* p = env->GetStringUTFChars(path, nullptr);
  std::string r = run(p);
  env->ReleaseStringUTFChars(path, p);
  return env->NewStringUTF(r.c_str());
}

static std::string resultJson(const runtime::RunResult& r) {
  JsonWriter j;
  j.beginObject().kvb("ran", r.ran).kvb("crashed", r.crashed).key("exitCode").num(r.exitCode);
  j.kv("signal", r.signalName).kv("trapSymbol", r.trapSymbol).kv("error", r.error).kv("output", r.output);
  j.kvh("faultPc", r.faultPc).kvh("faultAddr", r.faultAddr).endObject();
  return j.str();
}

extern "C" JNIEXPORT jstring JNICALL Java_com_radeki_ios_Native_run(JNIEnv* env, jclass, jstring path) {
  const char* p = env->GetStringUTFChars(path, nullptr);
  runtime::RunResult r;
  try {
    std::ifstream f(p, std::ios::binary);
    if (!f) throw FormatError("cannot open extracted executable");
    std::vector<uint8_t> file{std::istreambuf_iterator<char>(f), {}};
    auto slices = macho::listSlices(file);
    auto ch = macho::chooseSlice(slices);
    if (!ch.index) throw FormatError(ch.reason);
    auto img = macho::parseSlice(file, slices[*ch.index]);
    r = runtime::runImage(img);
  } catch (const std::exception& e) {
    r.error = e.what();
  }
  env->ReleaseStringUTFChars(path, p);
  return env->NewStringUTF(resultJson(r).c_str());
}

// Runs the synthetic ARM64 test program natively on this device.
extern "C" JNIEXPORT jstring JNICALL Java_com_radeki_ios_Native_selfTest(JNIEnv* env, jclass) {
  runtime::RunResult r;
  try {
    auto bytes = synth::build({});
    auto img = macho::parseFile(bytes);
    r = runtime::runImage(img);
  } catch (const std::exception& e) {
    r.error = e.what();
  }
  return env->NewStringUTF(resultJson(r).c_str());
}
