// radeki CLI: analyze | convert | validate  (all support --json)
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iterator>
#include <string>

#include "binary_analysis/analysis.h"
#include "core/json.h"
#include "relinker/relinker.h"

using namespace radeki;

static std::vector<uint8_t> slurp(const char* p) {
  std::ifstream f(p, std::ios::binary);
  if (!f) throw FormatError(std::string("cannot open ") + p);
  return {std::istreambuf_iterator<char>(f), {}};
}

static void jsonImage(JsonWriter& j, const macho::Image& img, const analysis::Report& rep) {
  j.kv("arch", macho::archName(img.arch)).kvb("is64", img.is64).kv("uuid", img.uuid).kvu("segments", img.segments.size());
  if (img.entry) j.kvh("entry", *img.entry);
  j.kvb("chainedFixups", img.hasChainedFixups).kvu("fixups", img.fixups.size()).kvu("imports", img.imports.size());
  j.kvb("encrypted", img.cryptId != 0).kvb("codeSignature", img.hasCodeSignature).kvb("tls", img.hasTLS);
  j.kvb("objc", rep.objc).kvb("swift", rep.swift).kvb("metal", rep.metal).kvb("opengles", rep.gles).kvb("audio", rep.audio);
  j.kvu("instructions", rep.instructions).kvu("functions", rep.functions.size()).kvu("xrefs", rep.xrefs.size());
  j.kvu("pacSign", rep.pacSign).kvu("pacAuth", rep.pacAuth);
  j.key("frameworks").beginArray(); for (auto& f : rep.frameworks) j.str(f); j.endArray();
  j.key("importNames").beginArray(); for (auto& i : img.imports) j.str(i.name); j.endArray();
  j.key("blockers").beginArray(); for (auto& b : rep.blockers) j.str(b); j.endArray();
}

int main(int argc, char** argv) {
  if (argc < 3) { fprintf(stderr, "usage: radeki analyze|convert|validate <macho> [-o dir] [--load-base 0x..] [--json]\n"); return 2; }
  std::string cmd = argv[1];
  bool json = false; const char* outDir = nullptr; uint64_t base = relinker::LinkOptions{}.loadBase;
  for (int i = 3; i < argc; ++i) {
    if (!strcmp(argv[i], "--json")) json = true;
    else if (!strcmp(argv[i], "-o") && i + 1 < argc) outDir = argv[++i];
    else if (!strcmp(argv[i], "--load-base") && i + 1 < argc) base = strtoull(argv[++i], nullptr, 0);
  }
  try {
    auto file = slurp(argv[2]);
    auto slices = macho::listSlices(file);
    auto choice = macho::chooseSlice(slices);
    if (!choice.index) throw FormatError(choice.reason);
    auto img = macho::parseSlice(file, slices[*choice.index]);
    auto rep = analysis::analyze(img);
    JsonWriter j; j.beginObject().kv("command", cmd).kv("sliceChoice", choice.reason);
    if (cmd == "analyze") {
      jsonImage(j, img, rep);
    } else if (cmd == "convert" || cmd == "validate") {
      relinker::CompatRegistry none;  // no compatibility libraries exist yet: every import is reported unresolved
      relinker::LinkOptions o; o.loadBase = base; o.resolver = &none;
      auto li = relinker::link(img, o);
      auto v = relinker::validate(li);
      j.kvh("loadBase", li.loadBase).kvu("imageSize", li.imageSize).kvu("rebases", li.rebases).kvu("binds", li.binds);
      if (li.entry) j.kvh("entry", *li.entry);
      j.kvb("validated", v.ok()).kvu("referencesChecked", v.checked);
      j.key("violations").beginArray(); for (auto& x : v.violations) j.beginObject().kvh("addr", x.addr).kv("what", x.what).endObject(); j.endArray();
      j.key("unresolvedImports").beginArray(); for (auto& t : li.traps) j.beginObject().kv("symbol", t.symbol).kvh("trap", t.addr).endObject(); j.endArray();
      if (cmd == "convert") {
        if (!outDir) throw FormatError("convert needs -o <dir>");
        std::string d = outDir;
        std::ofstream(d + "/image.bin", std::ios::binary).write((const char*)li.memory.data(), li.memory.size());
      }
      if (!v.ok()) { j.endObject(); puts(j.str().c_str()); return 1; }
    } else throw FormatError("unknown command");
    j.endObject();
    if (json) puts(j.str().c_str());
    else puts(j.str().c_str());  // human-readable formatting is a later task; JSON is authoritative
    return 0;
  } catch (const std::exception& e) {
    fprintf(stderr, "error: %s\n", e.what());
    return 1;
  }
}
