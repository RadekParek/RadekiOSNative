#include "loader/dyld.h"

#include <algorithm>
#include <functional>

namespace radeki::loader {
namespace {

constexpr size_t kNone = static_cast<size_t>(-1);
constexpr int kMaxReexportDepth = 8;

std::string leafName(const std::string& p) {
  size_t k = p.rfind('/');
  return k == std::string::npos ? p : p.substr(k + 1);
}

}  // namespace

size_t Registry::indexOf(const std::string& path) const {
  if (path.empty()) return kNone;
  for (size_t i = 0; i < entries_.size(); ++i)
    if (entries_[i].path == path || (!entries_[i].installName.empty() && entries_[i].installName == path)) return i;
  std::string leaf = leafName(path);
  for (size_t i = 0; i < entries_.size(); ++i) {
    if (leafName(entries_[i].path) == leaf) return i;
    if (!entries_[i].installName.empty() && leafName(entries_[i].installName) == leaf) return i;
  }
  return kNone;
}

int Registry::add(const Spec& spec) {
  if (spec.path.empty() || !spec.image) return -1;
  if (indexOf(spec.path) != kNone) return -1;
  if (spec.executable && executable()) return -1;
  Entry e;
  e.path = spec.path;
  e.image = spec.image;
  e.executable = spec.executable;
  e.global = spec.global;
  for (const auto& d : spec.image->dylibs) {
    if (d.kind == macho::DylibKind::Id) {
      if (e.installName.empty()) e.installName = d.name;
    } else {
      e.dependencies.push_back(d);
    }
  }
  entries_.push_back(std::move(e));
  return static_cast<int>(entries_.size() - 1);
}

const Entry* Registry::find(const std::string& path) const {
  size_t i = indexOf(path);
  return i == kNone ? nullptr : &entries_[i];
}

const Entry* Registry::executable() const {
  for (const auto& e : entries_)
    if (e.executable) return &e;
  return nullptr;
}

std::vector<Export> Registry::exportsOf(const std::string& path) const {
  size_t i = indexOf(path);
  return i == kNone ? std::vector<Export>{} : entries_[i].exports;
}

void Registry::collectExports(size_t index, uint64_t slide) {
  Entry& e = entries_[index];
  e.exports.clear();
  for (const auto& s : e.image->symbols) {
    if (s.undefined() || s.stab() || !s.external() || s.name.empty()) continue;
    e.exports.push_back({s.name, s.value + slide});
  }
}

std::optional<uint64_t> Registry::lookupIn(size_t index, const std::string& symbol, int depth) const {
  const Entry& e = entries_[index];
  if (!e.linked || depth > kMaxReexportDepth) return std::nullopt;
  for (const auto& x : e.exports)
    if (x.name == symbol) return x.addr;
  // LC_REEXPORT_DYLIB: the re-exporting image hands the symbol through unchanged.
  for (const auto& d : e.dependencies) {
    if (d.kind != macho::DylibKind::Reexport) continue;
    size_t j = indexOf(d.name);
    if (j == kNone || j == index) continue;
    if (auto v = lookupIn(j, symbol, depth + 1)) return v;
  }
  return std::nullopt;
}

std::optional<uint64_t> Registry::resolve(const std::string& symbol, const std::string& dylib) const {
  if (!opt_) return std::nullopt;
  // 1. two-level namespace: only the named image (plus what it re-exports) is searched.
  if (!dylib.empty()) {
    size_t i = indexOf(dylib);
    if (i != kNone)
      if (auto v = lookupIn(i, symbol, 0)) return v;
  }
  // 2. flat lookup (dyld ordinal -2, or ordinal 0 "self"): every global image in link order.
  if (opt_->flatFallback)
    for (size_t i = 0; i < entries_.size(); ++i)
      if (entries_[i].global)
        if (auto v = lookupIn(i, symbol, 0)) return v;
  // 3. compatibility libraries (libSystem subset) and anything else the caller supplied.
  if (opt_->fallback) return opt_->fallback->resolve(symbol, dylib);
  return std::nullopt;
}

std::optional<compat::CompatEntry> Registry::describe(const std::string& symbol, const std::string& dylib) const {
  if (!opt_) return std::nullopt;
  if (!dylib.empty()) {
    size_t i = indexOf(dylib);
    if (i != kNone && lookupIn(i, symbol, 0))
      return compat::CompatEntry{compat::SymbolClass::IOSFramework, dylib, "image_export"};
  }
  if (opt_->flatFallback)
    for (size_t i = 0; i < entries_.size(); ++i)
      if (entries_[i].global && lookupIn(i, symbol, 0))
        return compat::CompatEntry{compat::SymbolClass::IOSFramework, entries_[i].path, "image_export"};
  if (opt_->fallback) return opt_->fallback->describe(symbol, dylib);
  return std::nullopt;
}

LoadResult Registry::linkAll(const Options& opt) {
  LoadResult res;
  opt_ = &opt;
  if (opt.firstBase % relinker::kPageSize || opt.spacing == 0 || opt.spacing % relinker::kPageSize) {
    res.errors.push_back("loader options: firstBase and spacing must be non-zero and 16K aligned");
    return res;
  }
  if (entries_.empty()) {
    res.warnings.push_back("no images registered");
    return res;
  }

  // Dependency-first ordering; registration order breaks ties; the executable goes last.
  std::vector<size_t> order;
  {
    std::vector<bool> done(entries_.size(), false);
    std::function<void(size_t)> visit = [&](size_t i) {
      if (done[i]) return;
      done[i] = true;  // set before recursing, so a dependency cycle cannot spin
      for (const auto& d : entries_[i].dependencies) {
        size_t j = indexOf(d.name);
        if (j != kNone && j != i) visit(j);
      }
      order.push_back(i);
    };
    for (size_t i = 0; i < entries_.size(); ++i)
      if (!entries_[i].executable) visit(i);
    for (size_t i = 0; i < entries_.size(); ++i)
      if (entries_[i].executable) visit(i);
  }

  // A second linkAll() on the same registry starts from a clean slate.
  for (auto& e : entries_) {
    e.linked = false;
    e.failed = false;
    e.error.clear();
    e.exports.clear();
    e.warnings.clear();
  }

  // Two passes. Pass 1 lays the images out and links them against whatever is already
  // prepared, which is what fixes every image's size. Pass 2 republishes the complete export
  // table (all slides are known by then) and links again, so an import can bind to an image
  // that is registered after its importer -- the case a flat-namespace lookup hits. Binding
  // does not change any image's size, so the pass-1 layout stays valid, and pass 2 can only
  // turn traps into real addresses, never the other way round.
  auto runPass = [&](bool assignBases, bool collect) {
    uint64_t base = opt.firstBase;
    for (size_t idx : order) {
      Entry& e = entries_[idx];
      if (assignBases) {
        e.loadBase = base;
      } else if (e.failed || e.image == nullptr) {
        // Already known to be unloadable (pass 1 saw it fail). Its error still has to reach
        // the report -- silently skipping it would make LoadResult::ok() lie.
        if (collect && !e.error.empty() && std::find(res.errors.begin(), res.errors.end(), e.error) == res.errors.end())
          res.errors.push_back(e.error);
        continue;
      }

      try {
        e.slide = e.loadBase - e.image->textBase();
      } catch (const FormatError& ex) {
        e.failed = true;
        e.linked = false;
        e.exports.clear();
        e.error = e.path + ": " + ex.what();
        if (collect && std::find(res.errors.begin(), res.errors.end(), e.error) == res.errors.end())
          res.errors.push_back(e.error);
        base += opt.spacing;
        continue;
      }
      // Exports are published before this image binds, so an import with the "self" ordinal
      // resolves inside its own image the way dyld resolves it.
      collectExports(idx, e.slide);
      e.linked = true;

      relinker::LinkOptions lo;
      lo.loadBase = e.loadBase;
      lo.resolver = this;
      lo.veneerSlots = opt.veneerSlots;
      try {
        e.linkedImage = relinker::link(*e.image, lo);
      } catch (const relinker::LinkError& ex) {
        e.linked = false;
        e.exports.clear();
        e.failed = true;
        e.error = e.path + ": link failed: " + ex.what();
        if (collect && std::find(res.errors.begin(), res.errors.end(), e.error) == res.errors.end())
          res.errors.push_back(e.error);
        base += opt.spacing;
        continue;
      }
      e.failed = false;
      e.error.clear();
      e.imageSize = e.linkedImage.imageSize;
      e.totalSize = e.linkedImage.totalSize;

      if (collect) {
        e.warnings.clear();
        for (const auto& w : e.linkedImage.warnings) e.warnings.push_back(w);
        // Report what could not be bound. Weak imports land here too, with trap == 0, because
        // dyld binds an unsatisfied weak import to null rather than failing.
        for (const auto& b : e.linkedImage.imports) {
          if (b.resolved) continue;
          bool dup = false;
          for (const auto& u : res.unresolved)
            if (u.path == e.path && u.symbol == b.symbol && u.dylib == b.dylib) { dup = true; break; }
          if (dup) continue;
          UnresolvedImport u;
          u.path = e.path;
          u.symbol = b.symbol;
          u.dylib = b.dylib;
          u.weak = b.weak;
          for (const auto& t : e.linkedImage.traps)
            if (t.symbol == b.symbol) { u.trap = t.addr; break; }
          res.unresolved.push_back(std::move(u));
        }
        if (!e.executable && e.installName.empty())
          res.warnings.push_back(e.path + ": dylib has no LC_ID_DYLIB, so nothing can import from it by name");
      }
      base += std::max(opt.spacing, alignUp(e.totalSize, relinker::kPageSize));
    }
  };

  runPass(/*assignBases=*/true, /*collect=*/false);
  res.unresolved.clear();
  runPass(/*assignBases=*/false, /*collect=*/true);

  res.order.clear();
  for (size_t idx : order)
    if (entries_[idx].image) res.order.push_back(&entries_[idx]);
  return res;
}

}  // namespace radeki::loader
