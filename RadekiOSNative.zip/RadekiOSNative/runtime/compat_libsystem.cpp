#include <cstdlib>
#include <cstring>
#include <ctime>
#include <mutex>
#include <unistd.h>

#include "runtime/runtime.h"
#ifdef __ANDROID__
#include <android/log.h>
#endif

namespace radeki::runtime {
namespace {
std::mutex g_outMutex;
std::string g_out;
uint64_t g_stackGuard = 0x2F4A1B9C7D3E5A60ull;

int c_puts(const char* s) {
  appendGuestOutput(std::string(s ? s : "(null)") + "\n");
  return 1;
}
int c_putchar(int c) { appendGuestOutput(std::string(1, char(c))); return c; }
void c_exit(int code) { abortGuest(code, nullptr); }
void c_abort() { abortGuest(134, "abort() called"); }
void c_stack_chk_fail() { abortGuest(134, "stack check failed"); }
int c_abs(int x) { return x < 0 ? -x : x; }
char* c_strchr(const char* s, int c) { return const_cast<char*>(std::strchr(s, c)); }
void* c_memcpy_chk(void* d, const void* s, size_t n, size_t dl) {
  if (n > dl) abortGuest(134, "__memcpy_chk overflow");
  return std::memcpy(d, s, n);
}
void* c_memset_chk(void* d, int c, size_t n, size_t dl) {
  if (n > dl) abortGuest(134, "__memset_chk overflow");
  return std::memset(d, c, n);
}
template <class F> uint64_t addr(F* f) { return reinterpret_cast<uint64_t>(f); }
}  // namespace

void appendGuestOutput(const std::string& s) {
  std::lock_guard<std::mutex> l(g_outMutex);
  g_out += s;
#ifdef __ANDROID__
  __android_log_write(ANDROID_LOG_INFO, "RadekiGuest", s.c_str());
#endif
}
std::string takeGuestOutput() {
  std::lock_guard<std::mutex> l(g_outMutex);
  std::string r;
  r.swap(g_out);
  return r;
}

relinker::CompatRegistry makeCompatRegistry() {
  relinker::CompatRegistry r;
  r.add("_puts", addr(c_puts));
  r.add("_putchar", addr(c_putchar));
  r.add("_exit", addr(c_exit));
  r.add("__exit", addr(c_exit));
  r.add("_abort", addr(c_abort));
  r.add("___stack_chk_fail", addr(c_stack_chk_fail));
  r.add("___stack_chk_guard", reinterpret_cast<uint64_t>(&g_stackGuard));  // data symbol
  r.add("___memcpy_chk", addr(c_memcpy_chk));
  r.add("___memset_chk", addr(c_memset_chk));
  r.add("_abs", addr(c_abs));
  r.add("_strchr", addr(c_strchr));
  // Plain libc functions with identical AArch64 calling convention.
  r.add("_malloc", addr(&std::malloc));
  r.add("_free", addr(&std::free));
  r.add("_calloc", addr(&std::calloc));
  r.add("_realloc", addr(&std::realloc));
  r.add("_memcpy", addr(&std::memcpy));
  r.add("_memmove", addr(&std::memmove));
  r.add("_memset", addr(&std::memset));
  r.add("_memcmp", addr(&std::memcmp));
  r.add("_strlen", addr(&std::strlen));
  r.add("_strcmp", addr(&std::strcmp));
  r.add("_strncmp", addr(&std::strncmp));
  r.add("_strcpy", addr(&std::strcpy));
  r.add("_strncpy", addr(&std::strncpy));
  r.add("_strdup", addr(&::strdup));
  r.add("_atoi", addr(&std::atoi));
  r.add("_usleep", addr(&::usleep));
  r.add("_sleep", addr(&::sleep));
  r.add("_getpid", addr(&::getpid));
  r.add("_time", addr(&std::time));
  return r;
}

}  // namespace radeki::runtime
