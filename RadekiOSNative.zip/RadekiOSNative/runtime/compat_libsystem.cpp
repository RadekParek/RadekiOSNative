#include <cstdlib>
#include <cstring>
#include <ctime>
#include <mutex>
#include <cmath>
#include <map>
#include <pthread.h>
#include <unistd.h>

#include "runtime/runtime.h"
#ifdef __ANDROID__
#include <android/log.h>
#endif

namespace radeki::runtime {
namespace {
std::mutex g_outMutex;
std::string g_out;
uint64_t g_stackGuard = 0x2F4A1B9C7D3E5A60ull;

// Guest output has exactly one reader (runtime::run), but imports can be called from any
// thread, so every append is serialised by g_outMutex.

int c_puts(const char* s) {
  appendGuestOutput(std::string(s ? s : "(null)") + "\n");
  return 1;
}
int c_putchar(int c) { appendGuestOutput(std::string(1, char(c))); return c; }
void c_exit(int code) { abortGuest(code, nullptr); }
void c_abort() { abortGuest(134, "abort() called"); }
void c_stack_chk_fail() { abortGuest(134, "stack check failed"); }
int c_abs(int x) { return x < 0 ? -x : x; }
char* c_strchr(const char* s, int c) { return const_cast<char*>(std::strchr(s, c)); }
void* c_memcpy_chk(void* d, const void* s, size_t n, size_t dl) {
  if (n > dl) abortGuest(134, "__memcpy_chk overflow");
  return std::memcpy(d, s, n);
}
void* c_memset_chk(void* d, int c, size_t n, size_t dl) {
  if (n > dl) abortGuest(134, "__memset_chk overflow");
  return std::memset(d, c, n);
}
// --- pthread subset -------------------------------------------------------------------
// A trampoline is needed instead of a direct bind: the guest passes the Apple-sized
// pthread_attr_t and a handler whose signature is not ours (4 arguments there, 3 here).
struct ThreadJob {
  void* (*fn)(void*) = nullptr;
  void* arg = nullptr;
  void* ret = nullptr;
};

void* threadEntry(void* p) {
  auto* job = static_cast<ThreadJob*>(p);
  job->ret = job->fn ? job->fn(job->arg) : nullptr;
  return job->ret;
}

int c_pthread_create(uint64_t* threadOut, const void* attr, uint64_t start, void* arg) {
  (void)attr;  // Apple's pthread_attr_t layout is not our host's; only the default is honoured
  auto* job = new ThreadJob{reinterpret_cast<void* (*)(void*)>(start), arg, nullptr};
  pthread_t th;
  int rc = pthread_create(&th, nullptr, threadEntry, job);
  if (rc != 0) {
    delete job;
    return rc;
  }
  if (threadOut) {
    // pthread_t is an opaque pointer on Apple and an unsigned long on Linux; both fit in 8 bytes.
    uint64_t v = 0;
    static_assert(sizeof(th) <= sizeof v, "pthread_t must fit in a 64-bit guest slot");
    std::memcpy(&v, &th, sizeof th);
    *threadOut = v;
  }
  return 0;
}

int c_pthread_join(uint64_t thread, void** retval) {
  pthread_t th;
  std::memcpy(&th, &thread, sizeof th);
  int rc = pthread_join(th, retval);
  return rc;
}

uint64_t c_pthread_self() {
  uint64_t v = 0;
  pthread_t th = pthread_self();
  std::memcpy(&v, &th, sizeof th);
  return v;
}

int c_pthread_mutex_init(uint64_t* mutex, const void* attr) {
  (void)attr;  // PTHREAD_MUTEX_INITIALIZER semantics: Apple and glibc both use an all-zero object
  *mutex = 0;
  return 0;
}
int c_pthread_mutex_destroy(uint64_t* mutex) { *mutex = 0; return 0; }

// Static, non-recursive mutexes are the only kind the guest can create here, because the
// Apple layout never reaches the host kernel. This is a compat shim, not a real pthread.
struct MutexTable {
  std::mutex table;
  std::map<uint64_t, std::mutex> slots;
};
MutexTable& mutexTable() {
  static MutexTable t;
  return t;
}

int c_pthread_mutex_lock(uint64_t* mutex) {
  if (!mutex) return 22;  // EINVAL
  MutexTable& t = mutexTable();
  std::lock_guard<std::mutex> l(t.table);
  t.slots[*mutex].lock();
  return 0;
}
int c_pthread_mutex_unlock(uint64_t* mutex) {
  if (!mutex) return 22;
  MutexTable& t = mutexTable();
  std::lock_guard<std::mutex> l(t.table);
  auto it = t.slots.find(*mutex);
  if (it == t.slots.end()) return 22;
  it->second.unlock();
  return 0;
}

template <class F> uint64_t addr(F* f) { return reinterpret_cast<uint64_t>(f); }
}  // namespace

// Doctrine for this file: a symbol is registered here only when the guest-visible ABI is
// identical to the host function it points at, or when a written shim can honestly reproduce
// the documented behaviour. Nothing is stubbed to "succeed": anything we cannot back is left
// unregistered, and the relinker turns it into a named BRK trap that reports itself.

// _exit/_abort end the current run: abortGuest() unwinds back into runtime::run(), which
// reports the exit code, so the guest stops at the same point it would on iOS.
void appendGuestOutput(const std::string& s) {
  std::lock_guard<std::mutex> l(g_outMutex);
  g_out += s;
#ifdef __ANDROID__
  __android_log_write(ANDROID_LOG_INFO, "RadekiGuest", s.c_str());
#endif
}
std::string takeGuestOutput() {
  std::lock_guard<std::mutex> l(g_outMutex);
  std::string r;
  r.swap(g_out);
  return r;
}

relinker::CompatRegistry makeCompatRegistry() {
  relinker::CompatRegistry r;
  r.add("_puts", addr(c_puts));
  r.add("_putchar", addr(c_putchar));
  r.add("_exit", addr(c_exit));
  r.add("__exit", addr(c_exit));
  r.add("_abort", addr(c_abort));
  r.add("___stack_chk_fail", addr(c_stack_chk_fail));
  r.add("___stack_chk_guard", reinterpret_cast<uint64_t>(&g_stackGuard));  // data symbol
  r.add("___memcpy_chk", addr(c_memcpy_chk));
  r.add("___memset_chk", addr(c_memset_chk));
  r.add("_abs", addr(c_abs));
  r.add("_strchr", addr(c_strchr));
  // Plain libc functions with identical AArch64 calling convention.
  r.add("_malloc", addr(&std::malloc));
  r.add("_free", addr(&std::free));
  r.add("_calloc", addr(&std::calloc));
  r.add("_realloc", addr(&std::realloc));
  r.add("_memcpy", addr(&std::memcpy));
  r.add("_memmove", addr(&std::memmove));
  r.add("_memset", addr(&std::memset));
  r.add("_memcmp", addr(&std::memcmp));
  r.add("_strlen", addr(&std::strlen));
  r.add("_strcmp", addr(&std::strcmp));
  r.add("_strncmp", addr(&std::strncmp));
  r.add("_strcpy", addr(&std::strcpy));
  r.add("_strncpy", addr(&std::strncpy));
  r.add("_strdup", addr(&::strdup));
  r.add("_atoi", addr(&std::atoi));
  r.add("_usleep", addr(&::usleep));
  r.add("_sleep", addr(&::sleep));
  r.add("_getpid", addr(&::getpid));
  r.add("_time", addr(&std::time));
  r.add("_strerror", addr(&std::strerror));
  r.add("_strcat", addr(&std::strcat));
  r.add("_strncat", addr(&std::strncat));
  r.add("_strstr", addr(static_cast<char* (*)(char*, const char*)>(&std::strstr)));
  r.add("_strrchr", addr(static_cast<char* (*)(char*, int)>(&std::strrchr)));
  r.add("_strtol", addr(&std::strtol));
  r.add("_strtoul", addr(&std::strtoul));
  r.add("_atol", addr(&std::atol));
  // pthread subset: the only shims here that could not be bound directly, because Apple's
  // pthread_attr_t/trampoline conventions are not the host's. See the notes above.
  r.add("_pthread_create", addr(c_pthread_create));
  r.add("_pthread_join", addr(c_pthread_join));
  r.add("_pthread_self", addr(c_pthread_self));
  r.add("_pthread_mutex_init", addr(c_pthread_mutex_init));
  r.add("_pthread_mutex_destroy", addr(c_pthread_mutex_destroy));
  r.add("_pthread_mutex_lock", addr(c_pthread_mutex_lock));
  r.add("_pthread_mutex_unlock", addr(c_pthread_mutex_unlock));
  // libm: ordinary C functions taking and returning doubles, so the AArch64 ABI matches.
  r.add("_fabs", addr(static_cast<double (*)(double)>(&std::fabs)));
  r.add("_sqrt", addr(static_cast<double (*)(double)>(&std::sqrt)));
  r.add("_pow", addr(static_cast<double (*)(double, double)>(&std::pow)));
  r.add("_fmod", addr(static_cast<double (*)(double, double)>(&std::fmod)));
  r.add("_sin", addr(static_cast<double (*)(double)>(&std::sin)));
  r.add("_cos", addr(static_cast<double (*)(double)>(&std::cos)));
  r.add("_floor", addr(static_cast<double (*)(double)>(&std::floor)));
  r.add("_ceil", addr(static_cast<double (*)(double)>(&std::ceil)));
  r.add("_log", addr(static_cast<double (*)(double)>(&std::log)));
  r.add("_exp", addr(static_cast<double (*)(double)>(&std::exp)));
  return r;
}

}  // namespace radeki::runtime
