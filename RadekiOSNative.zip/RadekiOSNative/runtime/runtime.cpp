#include "runtime/runtime.h"

#include <pthread.h>
#include <setjmp.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <ucontext.h>
#include <unistd.h>

#include <cstring>
#include <mutex>

#ifndef MAP_FIXED_NOREPLACE
#define MAP_FIXED_NOREPLACE 0x100000
#endif

namespace radeki::runtime {
namespace {

std::mutex g_runMutex;
sigjmp_buf g_jmp;
volatile sig_atomic_t g_active = 0;
volatile sig_atomic_t g_sigCaught = 0;
volatile pid_t g_guestTid = 0;
uint64_t g_pc = 0, g_addr = 0;
int g_exitCode = 0;
const char* g_reason = nullptr;
const int kSignals[] = {SIGSEGV, SIGBUS, SIGILL, SIGTRAP};
struct sigaction g_old[4];

pid_t tid() { return static_cast<pid_t>(syscall(SYS_gettid)); }

uint64_t pcOf(void* ctx) {
  auto* uc = static_cast<ucontext_t*>(ctx);
#if defined(__aarch64__)
  return uc->uc_mcontext.pc;
#elif defined(__x86_64__)
  return static_cast<uint64_t>(uc->uc_mcontext.gregs[REG_RIP]);
#else
  (void)uc;
  return 0;
#endif
}

void onSignal(int sig, siginfo_t* si, void* ctx) {
  if (g_active && tid() == g_guestTid) {
    g_sigCaught = sig;
    g_pc = pcOf(ctx);
    g_addr = reinterpret_cast<uint64_t>(si->si_addr);
    siglongjmp(g_jmp, 1);
  }
  for (int i = 0; i < 4; ++i) {
    if (kSignals[i] != sig) continue;
    struct sigaction& o = g_old[i];
    if ((o.sa_flags & SA_SIGINFO) && o.sa_sigaction) { o.sa_sigaction(sig, si, ctx); return; }
    if (o.sa_handler != SIG_DFL && o.sa_handler != SIG_IGN && o.sa_handler) { o.sa_handler(sig); return; }
  }
  signal(sig, SIG_DFL);
  raise(sig);
}

const char* sigName(int s) {
  switch (s) {
    case SIGSEGV: return "SIGSEGV";
    case SIGBUS: return "SIGBUS";
    case SIGILL: return "SIGILL";
    case SIGTRAP: return "SIGTRAP";
    default: return "signal";
  }
}

struct Job {
  const relinker::LinkedImage* li;
  RunResult res;
};

[[maybe_unused]] void* guestThread(void* p) {
  Job* job = static_cast<Job*>(p);
  const relinker::LinkedImage& li = *job->li;
  RunResult& res = job->res;

  // 1. Map the image at its link address and copy bytes in.
  void* m = mmap(reinterpret_cast<void*>(li.loadBase), li.totalSize, PROT_READ | PROT_WRITE,
                 MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED_NOREPLACE, -1, 0);
  if (m == MAP_FAILED || reinterpret_cast<uint64_t>(m) != li.loadBase) {
    if (m != MAP_FAILED) munmap(m, li.totalSize);
    res.error = "map failed: could not map image at requested base";
    return nullptr;
  }
  std::memcpy(m, li.memory.data(), li.totalSize);
  // 2. Apply segment protections (W^X) and flush the instruction cache.
  for (const auto& r : li.regions) {
    if (r.prot == 0) continue;
    if (mprotect(reinterpret_cast<void*>(r.addr), r.size, static_cast<int>(r.prot & 7)) != 0) {
      res.error = "map failed: mprotect failed for " + r.name;
      munmap(m, li.totalSize);
      return nullptr;
    }
    if (r.code) __builtin___clear_cache(reinterpret_cast<char*>(r.addr), reinterpret_cast<char*>(r.addr + r.size));
  }
  if (!li.entry) { res.error = "image has no entry point"; return nullptr; }

  // 3. Install fault handlers and call into guest code.
  g_guestTid = tid();
  g_sigCaught = 0;
  g_reason = nullptr;
  struct sigaction sa;
  std::memset(&sa, 0, sizeof sa);
  sa.sa_sigaction = onSignal;
  sa.sa_flags = SA_SIGINFO | SA_NODEFER;
  sigemptyset(&sa.sa_mask);
  for (int i = 0; i < 4; ++i) sigaction(kSignals[i], &sa, &g_old[i]);

  static char arg0[] = "/var/containers/Bundle/Application/RadekiGuest";
  char* argv[] = {arg0, nullptr};
  char* envp[] = {nullptr};
  char* apple[] = {nullptr};
  using MainFn = int (*)(int, char**, char**, char**);
  using InitFn = void (*)(int, char**, char**, char**);
  if (sigsetjmp(g_jmp, 1) == 0) {
    g_active = 1;
    for (uint64_t slot : li.initPointerSlots) {
      uint64_t fn = *reinterpret_cast<uint64_t*>(slot);
      if (fn) reinterpret_cast<InitFn>(fn)(1, argv, envp, apple);
    }
    int rc = reinterpret_cast<MainFn>(*li.entry)(1, argv, envp, apple);
    g_active = 0;
    res.ran = true;
    res.exitCode = rc;
  } else {
    g_active = 0;
    if (g_sigCaught) {
      res.crashed = true;
      res.signalName = sigName(g_sigCaught);
      res.faultPc = g_pc;
      res.faultAddr = g_addr;
      for (const auto& t : li.traps)
        if (t.addr == g_pc) res.trapSymbol = t.symbol;
    } else {
      res.ran = true;
      res.exitCode = g_exitCode;
      if (g_reason) res.error = g_reason;
    }
  }
  for (int i = 0; i < 4; ++i) sigaction(kSignals[i], &g_old[i], nullptr);
  return nullptr;
}

}  // namespace

void abortGuest(int code, const char* reason) {
  g_exitCode = code;
  g_reason = reason;
  g_sigCaught = 0;
  siglongjmp(g_jmp, 1);
}

RunResult run([[maybe_unused]] const relinker::LinkedImage& li) {
#if !defined(__aarch64__)
  RunResult r;
  r.error = "guest execution requires an ARM64 host; this build runs on a different CPU architecture";
  return r;
#else
  std::lock_guard<std::mutex> lock(g_runMutex);
  Job job{&li, {}};
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setstacksize(&attr, 8u << 20);
  pthread_t th;
  if (pthread_create(&th, &attr, guestThread, &job) != 0) {
    job.res.error = "could not create guest thread";
  } else {
    pthread_join(th, nullptr);
  }
  pthread_attr_destroy(&attr);
  job.res.output = takeGuestOutput();
  return job.res;
#endif
}

RunResult runImage(const macho::Image& img) {
  RunResult none;
  if (img.hasTLS) { none.error = "thread-local variables are not supported yet"; return none; }
  auto reg = makeCompatRegistry();
  const uint64_t candidates[] = {img.textBase(), 0x300000000ull, 0x500000000ull, 0x900000000ull};
  RunResult last;
  for (uint64_t base : candidates) {
    if (base % relinker::kPageSize) continue;
    relinker::LinkOptions o;
    o.loadBase = base;
    o.resolver = &reg;
    try {
      auto li = relinker::link(img, o);
      last = run(li);
    } catch (const relinker::LinkError& e) {
      last = RunResult{};
      last.error = std::string("link failed: ") + e.what();
      return last;
    }
    if (last.error.rfind("map failed", 0) != 0) return last;
  }
  return last;
}

}  // namespace radeki::runtime
