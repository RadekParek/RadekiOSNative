// Hand-written framework stubs. See framework_stubs.h for scope and honesty contract.
#include "runtime/framework_stubs.h"
#include "runtime/runtime.h"

#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

namespace radeki::runtime {
namespace {

size_t g_count = 0;

// --- written shims -------------------------------------------------------------------------
// AAPCS64: extra register/stack arguments the shims do not name are simply ignored. Floats
// arrive in d-registers the shims never read. Structs-by-value the shims never consume.

void* g_dummyPoolToken = &g_dummyPoolToken;  // any stable non-null pointer is a legal "token"
const char g_emptyString[] = "";

uint64_t passthrough(uint64_t v) { return v; }                    // objc retain family
void voidShim() {}                                                // fire-and-forget calls
void voidShim1(uint64_t) {}
void voidShim2(uint64_t, uint64_t) {}
uint64_t zeroShim() { return 0; }                                 // nil / NULL returns
uint64_t emptyStringShim() { return reinterpret_cast<uint64_t>(g_emptyString); }
uint64_t poolPushShim() { return reinterpret_cast<uint64_t>(g_dummyPoolToken); }
double zeroDoubleShim() { return 0.0; }

int uiApplicationMainShim(int argc, char** argv, const void* principal, const void* delegate) {
  (void)argc; (void)argv; (void)principal; (void)delegate;
  noteCompatCall("UIApplicationMain");
  appendGuestOutput("[radeki-stub] UIApplicationMain(...) -- no UIKit backend; reporting a "
                    "completed startup loop (exit 0)\n");
  return 0;  // the guest's main() treats this as "app exited normally"
}

void nsLogShim(const void* format, ...) {
  char buf[64];
  std::snprintf(buf, sizeof buf, "[radeki-stub] NSLog(fmt=%p) -- format not parsed\n", format);
  noteCompatCall("NSLog");
  appendGuestOutput(buf);
}

[[noreturn]] void objcExceptionThrowShim(uint64_t exception) {
  char buf[96];
  std::snprintf(buf, sizeof buf, "guest Objective-C exception at %p",
                reinterpret_cast<void*>(exception));
  abortGuest(134, buf);
}

using Fn = uint64_t;
void addShim(relinker::CompatRegistry& reg, const char* name, Fn fn, const char* fw) {
  reg.add(name, fn, {compat::SymbolClass::CompatibilityShim, fw, "shim"});
  ++g_count;
}

// DummyFrameworkClass instances keep stable addresses for the process lifetime; the guest
// stores these pointers in __objc_classrefs and (without an objc_msgSend backend) never
// dispatches through them. The containers are deliberately leaked (runtime singletons): their
// pointers must stay reachable for as long as any linked guest image exists.
DummyFrameworkClass& classStub(const char* name) {
  static auto& all = *new std::vector<DummyFrameworkClass*>();
  for (auto* c : all)
    if (std::strcmp(c->name, name) == 0) return *c;
  auto* c = new DummyFrameworkClass();
  std::snprintf(c->name, sizeof c->name, "%s", name);
  all.push_back(c);
  return *c;
}

void addClassPair(relinker::CompatRegistry& reg, const char* cls, const char* fw) {
  auto& stub = classStub(cls);
  uint64_t addr = reinterpret_cast<uint64_t>(&stub);
  reg.add(std::string("_OBJC_CLASS_$_") + cls, addr, {compat::SymbolClass::NoopStub, fw, "dummy_class"});
  reg.add(std::string("_OBJC_METACLASS_$_") + cls, addr, {compat::SymbolClass::NoopStub, fw, "dummy_class"});
  g_count += 2;
}

void addData(relinker::CompatRegistry& reg, const char* name, const char* fw, const char* label) {
  static auto& blocks = *new std::vector<DummyFrameworkClass*>();  // see classStub()
  auto* b = new DummyFrameworkClass();
  std::snprintf(b->name, sizeof b->name, "%s", label);
  blocks.push_back(b);
  reg.add(name, reinterpret_cast<uint64_t>(b), {compat::SymbolClass::NoopStub, fw, "dummy_data"});
  ++g_count;
}

// Specialized dummy wrappers required by the request (EAGL + UIApplication). Their leading
// DummyFrameworkClass member doubles as the _OBJC_CLASS_$_ registration target.
DummyEAGLContext g_dummyEAGLContext;
DummyEAGLSharegroup g_dummyEAGLSharegroup;
DummyUIApplication g_dummyUIApplication;

}  // namespace

void registerFrameworkStubs(relinker::CompatRegistry& reg) {
  using namespace compat;

  // --- libobjc runtime family (keeps object graphs alive through the startup loop) --------
  for (const char* n : {"_objc_msgSend", "_objc_msgSendSuper", "_objc_msgSendSuper2",
                        "_objc_msgSend_stret", "_objc_retain", "_objc_retainBlock",
                        "_objc_retainAutorelease", "_objc_autorelease",
                        "_objc_autoreleaseReturnValue", "_objc_retainAutoreleasedReturnValue",
                        "_objc_unsafeClaimAutoreleasedReturnValue", "_objc_loadWeakRetained",
                        "_objc_rootRetain", "_CFRetain"})
    addShim(reg, n, reinterpret_cast<Fn>(passthrough), "libobjc");
  for (const char* n : {"_objc_release", "_objc_storeStrong", "_objc_storeWeak",
                        "_objc_destroyWeak", "_objc_clear_deallocating", "_objc_setProperty",
                        "_objc_setProperty_nonatomic", "_objc_copyWeak", "_objc_moveWeak",
                        "_objc_autoreleasePoolPop"})
    addShim(reg, n, reinterpret_cast<Fn>(voidShim1), "libobjc");
  addShim(reg, "_objc_autoreleasePoolPush", reinterpret_cast<Fn>(poolPushShim), "libobjc");
  for (const char* n : {"_sel_registerName", "_sel_getUid"})
    addShim(reg, n, reinterpret_cast<Fn>(passthrough), "libobjc");
  addShim(reg, "_sel_getName", reinterpret_cast<Fn>(emptyStringShim), "libobjc");
  for (const char* n : {"_objc_getClass", "_objc_lookUpClass", "_objc_getMetaClass",
                        "_objc_getRequiredClass", "_objc_getAssociatedObject",
                        "_class_isMetaClass", "_class_respondsToSelector", "_object_getClass"})
    addShim(reg, n, reinterpret_cast<Fn>(zeroShim), "libobjc");
  addShim(reg, "_objc_setAssociatedObject", reinterpret_cast<Fn>(voidShim2), "libobjc");
  addShim(reg, "_objc_exception_throw", reinterpret_cast<Fn>(objcExceptionThrowShim), "libobjc");

  // --- CoreFoundation ----------------------------------------------------------------------
  addShim(reg, "_CFRelease", reinterpret_cast<Fn>(voidShim1), "CoreFoundation");
  for (const char* n : {"_CFGetTypeID", "_CFStringGetLength", "_CFStringCreateWithCString",
                        "_CFStringCreateMutable", "_CFBundleGetMainBundle", "_CFRunLoopGetCurrent",
                        "_CFRunLoopRunInMode", "_CFPreferencesCopyAppValue", "_CFShow"})
    addShim(reg, n, reinterpret_cast<Fn>(zeroShim), "CoreFoundation");
  addShim(reg, "_CFRunLoopRun", reinterpret_cast<Fn>(voidShim), "CoreFoundation");
  addShim(reg, "_CFRunLoopStop", reinterpret_cast<Fn>(voidShim1), "CoreFoundation");
  addShim(reg, "_CFAbsoluteTimeGetCurrent", reinterpret_cast<Fn>(zeroDoubleShim), "CoreFoundation");

  // --- UIKit --------------------------------------------------------------------------------
  addShim(reg, "_UIApplicationMain", reinterpret_cast<Fn>(uiApplicationMainShim), "UIKit");
  for (const char* n : {"_UIGraphicsGetCurrentContext", "_UIGraphicsGetImageFromCurrentImageContext",
                        "_UIImagePNGRepresentation", "_UIImageJPEGRepresentation"})
    addShim(reg, n, reinterpret_cast<Fn>(zeroShim), "UIKit");
  for (const char* n : {"_UIGraphicsBeginImageContext", "_UIGraphicsEndImageContext",
                        "_UIImageWriteToSavedPhotosAlbum"})
    addShim(reg, n, reinterpret_cast<Fn>(voidShim), "UIKit");
  addShim(reg, "_UIGraphicsBeginImageContextWithOptions", reinterpret_cast<Fn>(voidShim), "UIKit");

  // --- Foundation ---------------------------------------------------------------------------
  addShim(reg, "_NSLog", reinterpret_cast<Fn>(nsLogShim), "Foundation");
  for (const char* n : {"_NSSearchPathForDirectoriesInDomains", "_NSHomeDirectory",
                        "_NSTemporaryDirectory", "_NSUserName", "_NSFullUserName",
                        "_NSGetUncaughtExceptionHandler", "_NSClassFromString"})
    addShim(reg, n, reinterpret_cast<Fn>(zeroShim), "Foundation");
  addShim(reg, "_NSStringFromClass", reinterpret_cast<Fn>(emptyStringShim), "Foundation");
  addShim(reg, "_NSSetUncaughtExceptionHandler", reinterpret_cast<Fn>(voidShim1), "Foundation");

  // --- QuartzCore ---------------------------------------------------------------------------
  addShim(reg, "_CACurrentMediaTime", reinterpret_cast<Fn>(zeroDoubleShim), "QuartzCore");

  // --- dummy classes: the essential UIKit / EAGL / QuartzCore / Foundation set --------------
  const char* foundationClasses[] = {
      "NSObject", "NSProxy", "NSAutoreleasePool", "NSBundle", "NSString", "NSMutableString",
      "NSArray", "NSMutableArray", "NSDictionary", "NSMutableDictionary", "NSSet", "NSMutableSet",
      "NSNumber", "NSData", "NSMutableData", "NSDate", "NSError", "NSException", "NSValue",
      "NSNull", "NSURL", "NSThread", "NSTimer", "NSNotification", "NSNotificationCenter",
      "NSOperationQueue", "NSRunLoop", "NSUserDefaults", "NSFileManager", "NSLocale",
      "NSIndexPath", "NSProcessInfo", "NSUUID", "NSCache",
  };
  for (const char* c : foundationClasses) addClassPair(reg, c, "Foundation");
  const char* uikitClasses[] = {
      "UIResponder", "UIApplication", "UIScreen", "UIWindow", "UIView", "UIViewController",
      "UINavigationController", "UITabBarController", "UIImagePickerController", "UIImage",
      "UIImageView", "UILabel", "UIButton", "UIControl", "UIColor", "UIFont", "UIEvent",
      "UITouch", "UIGestureRecognizer", "UITapGestureRecognizer", "UIPanGestureRecognizer",
      "UIScrollView", "UITableView", "UITableViewCell", "UITextField", "UITextView",
      "UIActivityIndicatorView", "UIAlertView", "UIActionSheet", "UIDevice", "UIBezierPath",
      "UIWebView",
  };
  for (const char* c : uikitClasses) addClassPair(reg, c, "UIKit");
  const char* quartzClasses[] = {"CALayer", "CAEAGLLayer", "CADisplayLink", "CAAnimation", "CABasicAnimation"};
  for (const char* c : quartzClasses) addClassPair(reg, c, "QuartzCore");
  // EAGL + UIApplication get the specialized dummy wrappers (their leading class-stub member
  // is the registered target, so the extra fields sit right behind the class object).
  reg.add("_OBJC_CLASS_$_EAGLContext", reinterpret_cast<uint64_t>(&g_dummyEAGLContext.classStub),
          {SymbolClass::NoopStub, "OpenGLES", "dummy_class"});
  reg.add("_OBJC_METACLASS_$_EAGLContext", reinterpret_cast<uint64_t>(&g_dummyEAGLContext.classStub),
          {SymbolClass::NoopStub, "OpenGLES", "dummy_class"});
  reg.add("_OBJC_CLASS_$_EAGLSharegroup", reinterpret_cast<uint64_t>(&g_dummyEAGLSharegroup.classStub),
          {SymbolClass::NoopStub, "OpenGLES", "dummy_class"});
  reg.add("_OBJC_METACLASS_$_EAGLSharegroup", reinterpret_cast<uint64_t>(&g_dummyEAGLSharegroup.classStub),
          {SymbolClass::NoopStub, "OpenGLES", "dummy_class"});
  std::snprintf(g_dummyEAGLContext.classStub.name, sizeof g_dummyEAGLContext.classStub.name, "EAGLContext");
  std::snprintf(g_dummyEAGLSharegroup.classStub.name, sizeof g_dummyEAGLSharegroup.classStub.name, "EAGLSharegroup");
  std::snprintf(g_dummyUIApplication.classStub.name, sizeof g_dummyUIApplication.classStub.name, "UIApplication");
  g_count += 4;

  const char* avClasses[] = {"AVAudioPlayer", "AVAudioSession", "AVPlayer"};
  for (const char* c : avClasses) addClassPair(reg, c, "AVFoundation");
  const char* skClasses[] = {"SKPaymentQueue", "SKPayment", "SKPaymentTransaction",
                             "SKProductsRequest", "SKProduct"};
  for (const char* c : skClasses) addClassPair(reg, c, "StoreKit");
  addClassPair(reg, "ASIdentifierManager", "AdSupport");

  // --- data constants the startup code tends to reference ----------------------------------
  for (const char* n : {"_NSConcreteStackBlock", "_NSConcreteGlobalBlock", "_NSConcreteMallocBlock"})
    addData(reg, n, "libSystem", "NSConcreteBlock");
  for (const char* n : {"_kCFAllocatorDefault", "_kCFAllocatorMalloc", "_kCFAllocatorNull",
                        "_kCFAllocatorSystemDefault", "_kCFRunLoopDefaultMode",
                        "_kCFRunLoopCommonModes"})
    addData(reg, n, "CoreFoundation", n + 4);
  addData(reg, "_NSFoundationVersionNumber", "Foundation", "NSFoundationVersionNumber");
  for (const char* n : {"_UIWindowLevelNormal", "_UIWindowLevelAlert"})
    addData(reg, n, "UIKit", n + 1);
  for (const char* n : {"_UIApplicationDidFinishLaunchingNotification",
                        "_UIApplicationWillResignActiveNotification",
                        "_UIApplicationDidEnterBackgroundNotification",
                        "_UIApplicationWillEnterForegroundNotification",
                        "_UIApplicationDidBecomeActiveNotification",
                        "_UIKeyboardWillShowNotification", "_UIKeyboardDidShowNotification",
                        "_UIKeyboardWillHideNotification", "_UIKeyboardDidHideNotification"})
    addData(reg, n, "UIKit", n + 1);
}

size_t frameworkStubCount() { return g_count; }

}  // namespace radeki::runtime
