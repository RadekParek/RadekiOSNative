// Hand-written framework stubs + EAGL/UIKit/OpenGL ES 2.0 bridge.
#include "runtime/framework_stubs.h"
#include "runtime/runtime.h"

#include <dlfcn.h>
#include <sys/stat.h>
#include <unistd.h>

#include <atomic>
#include <cstdio>
#include <cstring>
#include <deque>
#include <filesystem>
#include <mutex>
#include <string>
#include <vector>

namespace radeki::runtime {
namespace {

size_t g_count = 0;
size_t g_glesCount = 0;

// Specialized dummy wrappers for EAGL + UIWindow + CADisplayLink + UIApplication.
DummyEAGLContext g_dummyEAGLContext;
DummyEAGLSharegroup g_dummyEAGLSharegroup;
DummyUIApplication g_dummyUIApplication;
DummyUIWindow g_dummyUIWindow;
DummyCADisplayLink g_dummyCADisplayLink;
DummyEAGLContext* g_currentEAGLContext = nullptr;

std::mutex g_bridgeMutex;
void* g_androidNativeWindow = nullptr;
int g_surfaceWidth = 1280;
int g_surfaceHeight = 720;

// Dynamic handles to Android's native libEGL.so and libGLESv2.so (if present on host/device).
struct NativeGles {
  void* eglLib = nullptr;
  void* glesLib = nullptr;
  // Minimal EGL function pointers resolved dynamically so this file compiles on both Android
  // NDK and headless Linux hosts without requiring EGL headers at compile time.
  using EglGetDisplayFn = void* (*)(void*);
  using EglInitFn = int (*)(void*, int*, int*);
  using EglChooseConfigFn = int (*)(void*, const int*, void**, int, int*);
  using EglCreatePbufferSurfaceFn = void* (*)(void*, void*, const int*);
  using EglCreateWindowSurfaceFn = void* (*)(void*, void*, void*, const int*);
  using EglBindApiFn = int (*)(unsigned int);
  using EglCreateContextFn = void* (*)(void*, void*, void*, const int*);
  using EglMakeCurrentFn = int (*)(void*, void*, void*, void*);
  using EglSwapBuffersFn = int (*)(void*, void*);
  using EglGetCurrentContextFn = void* (*)();

  EglGetDisplayFn eglGetDisplay = nullptr;
  EglInitFn eglInitialize = nullptr;
  EglChooseConfigFn eglChooseConfig = nullptr;
  EglCreatePbufferSurfaceFn eglCreatePbufferSurface = nullptr;
  EglCreateWindowSurfaceFn eglCreateWindowSurface = nullptr;
  EglBindApiFn eglBindAPI = nullptr;
  EglCreateContextFn eglCreateContext = nullptr;
  EglMakeCurrentFn eglMakeCurrent = nullptr;
  EglSwapBuffersFn eglSwapBuffers = nullptr;
  EglGetCurrentContextFn eglGetCurrentContext = nullptr;

  NativeGles() {
    for (const char* name : {"libEGL.so", "libEGL.so.1"}) {
      eglLib = dlopen(name, RTLD_LAZY | RTLD_LOCAL);
      if (eglLib) break;
    }
    for (const char* name : {"libGLESv2.so", "libGLESv2.so.2"}) {
      glesLib = dlopen(name, RTLD_LAZY | RTLD_LOCAL);
      if (glesLib) break;
    }
    auto symEgl = [&](const char* s) -> void* {
      if (eglLib) {
        if (void* p = dlsym(eglLib, s)) return p;
      }
      return dlsym(RTLD_DEFAULT, s);
    };
    eglGetDisplay = reinterpret_cast<EglGetDisplayFn>(symEgl("eglGetDisplay"));
    eglInitialize = reinterpret_cast<EglInitFn>(symEgl("eglInitialize"));
    eglChooseConfig = reinterpret_cast<EglChooseConfigFn>(symEgl("eglChooseConfig"));
    eglCreatePbufferSurface = reinterpret_cast<EglCreatePbufferSurfaceFn>(symEgl("eglCreatePbufferSurface"));
    eglCreateWindowSurface = reinterpret_cast<EglCreateWindowSurfaceFn>(symEgl("eglCreateWindowSurface"));
    eglBindAPI = reinterpret_cast<EglBindApiFn>(symEgl("eglBindAPI"));
    eglCreateContext = reinterpret_cast<EglCreateContextFn>(symEgl("eglCreateContext"));
    eglMakeCurrent = reinterpret_cast<EglMakeCurrentFn>(symEgl("eglMakeCurrent"));
    eglSwapBuffers = reinterpret_cast<EglSwapBuffersFn>(symEgl("eglSwapBuffers"));
    eglGetCurrentContext = reinterpret_cast<EglGetCurrentContextFn>(symEgl("eglGetCurrentContext"));
  }

  void* resolveGl(const char* name) const {
    if (glesLib) {
      if (void* p = dlsym(glesLib, name)) return p;
    }
    return dlsym(RTLD_DEFAULT, name);
  }

  bool hasCurrentHardwareContext() const {
    return eglGetCurrentContext && eglGetCurrentContext() != nullptr;
  }
};

NativeGles& nativeGles() {
  static NativeGles n;
  return n;
}

void ensureEglContextInitialized(DummyEAGLContext* ctx) {
  if (!ctx || ctx->eglContext != 0) return;
  NativeGles& ng = nativeGles();
  if (!ng.eglGetDisplay || !ng.eglInitialize || !ng.eglChooseConfig || !ng.eglCreateContext) return;
  void* dpy = ng.eglGetDisplay(nullptr);  // EGL_DEFAULT_DISPLAY
  if (!dpy) return;
  int major = 0, minor = 0;
  if (!ng.eglInitialize(dpy, &major, &minor)) return;
  if (ng.eglBindAPI) ng.eglBindAPI(0x30A0);  // EGL_OPENGL_ES_API
  // EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT (4), EGL_SURFACE_TYPE, EGL_PBUFFER_BIT|EGL_WINDOW_BIT (5),
  // EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_DEPTH_SIZE, 16, EGL_NONE (0x3038)
  const int configAttribs[] = {
      0x3040, 0x0004,
      0x3033, 0x0005,
      0x3024, 8,
      0x3023, 8,
      0x3022, 8,
      0x3025, 16,
      0x3038
  };
  void* cfg = nullptr;
  int numCfg = 0;
  if (!ng.eglChooseConfig(dpy, configAttribs, &cfg, 1, &numCfg) || numCfg < 1) return;
  // EGL_CONTEXT_CLIENT_VERSION (0x3098), 2, EGL_NONE (0x3038)
  const int ctxAttribs[] = {0x3098, 2, 0x3038};
  void* eglCtx = ng.eglCreateContext(dpy, cfg, nullptr, ctxAttribs);
  if (!eglCtx) return;
  void* surf = nullptr;
  if (g_androidNativeWindow && ng.eglCreateWindowSurface) {
    const int winAttribs[] = {0x3038};
    surf = ng.eglCreateWindowSurface(dpy, cfg, g_androidNativeWindow, winAttribs);
  }
  if (!surf && ng.eglCreatePbufferSurface) {
    // EGL_WIDTH (0x3057), g_surfaceWidth, EGL_HEIGHT (0x3056), g_surfaceHeight, EGL_NONE (0x3038)
    const int pbufAttribs[] = {0x3057, g_surfaceWidth, 0x3056, g_surfaceHeight, 0x3038};
    surf = ng.eglCreatePbufferSurface(dpy, cfg, pbufAttribs);
  }
  ctx->eglDisplay = reinterpret_cast<uint64_t>(dpy);
  ctx->eglSurface = reinterpret_cast<uint64_t>(surf);
  ctx->eglContext = reinterpret_cast<uint64_t>(eglCtx);
}

// Interned string storage for dynamic ObjC string operations (stringByAppendingPathComponent:, etc.)
std::mutex g_strPoolMutex;
std::deque<std::string> g_strPool;
const char* internDynamicString(std::string s) {
  std::lock_guard<std::mutex> lock(g_strPoolMutex);
  for (const auto& existing : g_strPool) {
    if (existing == s) return existing.c_str();
  }
  g_strPool.push_back(std::move(s));
  return g_strPool.back().c_str();
}

// Safe check for whether a 64-bit value looks like a mapped user-space pointer rather than a
// small synthetic integer (such as 0x1234 or 0xDEAD in unit tests).
bool looksLikeReadablePointer(uint64_t p) {
  if (p < 0x100000ull || p > 0x00007FFFFFFFFFFFull) return false;
  return true;
}

}  // namespace

DummyEAGLContext* eaglDefaultContext() {
  if (g_dummyEAGLContext.api == 0) g_dummyEAGLContext.api = 2;
  if (g_dummyEAGLContext.sharegroup == 0) {
    g_dummyEAGLContext.sharegroup = reinterpret_cast<uint64_t>(&g_dummyEAGLSharegroup.classStub);
  }
  return &g_dummyEAGLContext;
}

DummyEAGLContext* eaglInitWithAPI(void* self, uint32_t api) {
  noteCompatCall("EAGLContext::initWithAPI");
  std::lock_guard<std::mutex> lock(g_bridgeMutex);
  DummyEAGLContext* ctx = &g_dummyEAGLContext;
  if (self == &g_dummyEAGLContext) ctx = static_cast<DummyEAGLContext*>(self);
  ctx->api = api ? api : 2;
  ctx->sharegroup = reinterpret_cast<uint64_t>(&g_dummyEAGLSharegroup.classStub);
  ensureEglContextInitialized(ctx);
  return ctx;
}

int eaglSetCurrentContext(void* ctxPtr) {
  noteCompatCall("EAGLContext::setCurrentContext");
  std::lock_guard<std::mutex> lock(g_bridgeMutex);
  if (!ctxPtr) {
    if (g_currentEAGLContext) g_currentEAGLContext->isCurrent = 0;
    g_currentEAGLContext = nullptr;
    NativeGles& ng = nativeGles();
    if (ng.eglMakeCurrent && g_dummyEAGLContext.eglDisplay) {
      ng.eglMakeCurrent(reinterpret_cast<void*>(g_dummyEAGLContext.eglDisplay), nullptr, nullptr, nullptr);
    }
    return 1;
  }
  DummyEAGLContext* ctx = (ctxPtr == &g_dummyEAGLContext) ? static_cast<DummyEAGLContext*>(ctxPtr) : &g_dummyEAGLContext;
  if (ctx->api == 0) ctx->api = 2;
  if (ctx->sharegroup == 0) ctx->sharegroup = reinterpret_cast<uint64_t>(&g_dummyEAGLSharegroup.classStub);
  ensureEglContextInitialized(ctx);
  NativeGles& ng = nativeGles();
  if (ng.eglMakeCurrent && ctx->eglDisplay && ctx->eglContext) {
    void* surf = reinterpret_cast<void*>(ctx->eglSurface);
    ng.eglMakeCurrent(reinterpret_cast<void*>(ctx->eglDisplay), surf, surf,
                      reinterpret_cast<void*>(ctx->eglContext));
  }
  ctx->isCurrent = 1;
  g_currentEAGLContext = ctx;
  return 1;
}

DummyEAGLContext* eaglGetCurrentContext() {
  std::lock_guard<std::mutex> lock(g_bridgeMutex);
  return g_currentEAGLContext ? g_currentEAGLContext : &g_dummyEAGLContext;
}

int eaglPresentRenderbuffer(void* self, uint32_t /*target*/) {
  noteCompatCall("EAGLContext::presentRenderbuffer");
  std::lock_guard<std::mutex> lock(g_bridgeMutex);
  DummyEAGLContext* ctx = (self == &g_dummyEAGLContext) ? static_cast<DummyEAGLContext*>(self) : &g_dummyEAGLContext;
  ++ctx->presentedFrames;
  NativeGles& ng = nativeGles();
  if (ng.eglSwapBuffers && ctx->eglDisplay && ctx->eglSurface) {
    ng.eglSwapBuffers(reinterpret_cast<void*>(ctx->eglDisplay), reinterpret_cast<void*>(ctx->eglSurface));
  }
  return 1;
}

int eaglRenderbufferStorageFromDrawable(void* /*self*/, uint32_t target, void* /*drawable*/) {
  noteCompatCall("EAGLContext::renderbufferStorage:fromDrawable:");
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using GlRenderbufferStorageFn = void (*)(uint32_t, uint32_t, int, int);
    static auto fn = reinterpret_cast<GlRenderbufferStorageFn>(ng.resolveGl("glRenderbufferStorage"));
    if (fn) {
      // GL_RGBA8_OES (0x8058) or GL_RGB565 (0x8D62)
      fn(target ? target : 0x8D41, 0x8D62, g_surfaceWidth, g_surfaceHeight);
    }
  }
  return 1;
}

void bindAndroidEglWindow(void* nativeWindow, int width, int height) {
  std::lock_guard<std::mutex> lock(g_bridgeMutex);
  g_androidNativeWindow = nativeWindow;
  if (width > 0) g_surfaceWidth = width;
  if (height > 0) g_surfaceHeight = height;
}

DummyUIWindow* uiWindowDefault() { return &g_dummyUIWindow; }

int uiWindowMakeKeyAndVisible(void* window) {
  noteCompatCall("UIWindow::makeKeyAndVisible");
  std::lock_guard<std::mutex> lock(g_bridgeMutex);
  DummyUIWindow* w = (window == &g_dummyUIWindow) ? static_cast<DummyUIWindow*>(window) : &g_dummyUIWindow;
  w->keyAndVisible = 1;
  return 1;
}

DummyCADisplayLink* caDisplayLinkDefault() { return &g_dummyCADisplayLink; }

DummyCADisplayLink* caDisplayLinkWithTargetSelector(uint64_t target, uint64_t selector) {
  noteCompatCall("CADisplayLink::displayLinkWithTarget:selector:");
  std::lock_guard<std::mutex> lock(g_bridgeMutex);
  g_dummyCADisplayLink.target = target;
  g_dummyCADisplayLink.selector = selector;
  g_dummyCADisplayLink.frameInterval = 1;
  g_dummyCADisplayLink.duration = 1.0 / 60.0;
  return &g_dummyCADisplayLink;
}

int caDisplayLinkAddToRunLoop(void* link, uint64_t runLoop, uint64_t mode) {
  noteCompatCall("CADisplayLink::addToRunLoop:forMode:");
  std::lock_guard<std::mutex> lock(g_bridgeMutex);
  DummyCADisplayLink* dl = (link == &g_dummyCADisplayLink) ? static_cast<DummyCADisplayLink*>(link) : &g_dummyCADisplayLink;
  dl->runLoop = runLoop;
  dl->mode = mode;
  dl->registeredInRunLoop = 1;
  return 1;
}

namespace {

// --- written shims -------------------------------------------------------------------------
// AAPCS64: extra register/stack arguments the shims do not name are simply ignored. Floats
// arrive in d-registers the shims never read. Structs-by-value the shims never consume.

void* g_dummyPoolToken = &g_dummyPoolToken;  // any stable non-null pointer is a legal "token"
const char g_emptyString[] = "";

uint64_t passthrough(uint64_t v) { return v; }                    // objc retain family
void voidShim() {}                                                // fire-and-forget calls
void voidShim1(uint64_t) {}
void voidShim2(uint64_t, uint64_t) {}
uint64_t zeroShim() { return 0; }                                 // nil / NULL returns
uint64_t emptyStringShim() { return reinterpret_cast<uint64_t>(g_emptyString); }
uint64_t poolPushShim() { return reinterpret_cast<uint64_t>(g_dummyPoolToken); }
double zeroDoubleShim() { return 0.0; }

// Selector-aware objc_msgSend shim: bridges EAGLContext, UIWindow, CADisplayLink, and
// Foundation path/string selectors while preserving x0 pass-through for everything else.
uint64_t objcMsgSendShim(uint64_t self, uint64_t sel, uint64_t a0, uint64_t a1, uint64_t a2, uint64_t a3) {
  (void)a2;
  (void)a3;
  if (!looksLikeReadablePointer(sel)) return self;
  const char* s = reinterpret_cast<const char*>(sel);
  // Quickly validate first byte is printable identifier character.
  if (s[0] < 'A' || s[0] > 'z') return self;

  // --- EAGLContext methods ---
  if (std::strcmp(s, "initWithAPI:") == 0 || std::strcmp(s, "initWithAPI:sharegroup:") == 0) {
    return reinterpret_cast<uint64_t>(eaglInitWithAPI(reinterpret_cast<void*>(self), static_cast<uint32_t>(a0)));
  }
  if (std::strcmp(s, "setCurrentContext:") == 0) {
    return static_cast<uint64_t>(eaglSetCurrentContext(reinterpret_cast<void*>(a0)));
  }
  if (std::strcmp(s, "currentContext") == 0) {
    return reinterpret_cast<uint64_t>(eaglGetCurrentContext());
  }
  if (std::strcmp(s, "presentRenderbuffer:") == 0) {
    return static_cast<uint64_t>(eaglPresentRenderbuffer(reinterpret_cast<void*>(self), static_cast<uint32_t>(a0)));
  }
  if (std::strcmp(s, "renderbufferStorage:fromDrawable:") == 0) {
    return static_cast<uint64_t>(
        eaglRenderbufferStorageFromDrawable(reinterpret_cast<void*>(self), static_cast<uint32_t>(a0),
                                            reinterpret_cast<void*>(a1)));
  }
  if (std::strcmp(s, "sharegroup") == 0) {
    return reinterpret_cast<uint64_t>(&g_dummyEAGLSharegroup.classStub);
  }
  if (std::strcmp(s, "API") == 0) {
    return g_dummyEAGLContext.api ? g_dummyEAGLContext.api : 2;
  }

  // --- UIWindow / UIScreen / UIView methods ---
  if (std::strcmp(s, "makeKeyAndVisible") == 0) {
    uiWindowMakeKeyAndVisible(reinterpret_cast<void*>(self));
    return self ? self : reinterpret_cast<uint64_t>(&g_dummyUIWindow.classStub);
  }
  if (std::strcmp(s, "setRootViewController:") == 0) {
    g_dummyUIWindow.rootViewController = a0;
    return self;
  }
  if (std::strcmp(s, "rootViewController") == 0) {
    return g_dummyUIWindow.rootViewController;
  }

  // --- CADisplayLink methods ---
  if (std::strcmp(s, "displayLinkWithTarget:selector:") == 0) {
    return reinterpret_cast<uint64_t>(caDisplayLinkWithTargetSelector(a0, a1));
  }
  if (std::strcmp(s, "addToRunLoop:forMode:") == 0) {
    caDisplayLinkAddToRunLoop(reinterpret_cast<void*>(self), a0, a1);
    return self;
  }
  if (std::strcmp(s, "setFrameInterval:") == 0) {
    g_dummyCADisplayLink.frameInterval = static_cast<uint32_t>(a0 ? a0 : 1);
    return self;
  }
  if (std::strcmp(s, "setPaused:") == 0) {
    g_dummyCADisplayLink.paused = static_cast<uint32_t>(a0 != 0);
    return self;
  }
  if (std::strcmp(s, "invalidate") == 0) {
    g_dummyCADisplayLink.registeredInRunLoop = 0;
    return self;
  }

  // --- Foundation path / NSString / NSArray / NSBundle / NSFileManager methods ---
  if (std::strcmp(s, "UTF8String") == 0 ||
      std::strcmp(s, "fileSystemRepresentation") == 0 ||
      std::strcmp(s, "cStringUsingEncoding:") == 0) {
    if (looksLikeReadablePointer(self)) return self;
    return reinterpret_cast<uint64_t>(g_emptyString);
  }
  if (std::strcmp(s, "objectAtIndex:") == 0 ||
      std::strcmp(s, "firstObject") == 0 ||
      std::strcmp(s, "lastObject") == 0) {
    return self;
  }
  if (std::strcmp(s, "count") == 0) {
    return self ? 1 : 0;
  }
  if (std::strcmp(s, "stringWithUTF8String:") == 0 ||
      std::strcmp(s, "initWithUTF8String:") == 0 ||
      std::strcmp(s, "stringWithCString:encoding:") == 0) {
    if (looksLikeReadablePointer(a0)) {
      return reinterpret_cast<uint64_t>(internDynamicString(reinterpret_cast<const char*>(a0)));
    }
    return reinterpret_cast<uint64_t>(g_emptyString);
  }
  if (std::strcmp(s, "stringByAppendingPathComponent:") == 0) {
    std::string lhs = looksLikeReadablePointer(self) ? reinterpret_cast<const char*>(self) : "";
    std::string rhs = looksLikeReadablePointer(a0) ? reinterpret_cast<const char*>(a0) : "";
    if (!lhs.empty() && lhs.back() != '/' && !rhs.empty() && rhs.front() != '/') lhs += '/';
    return reinterpret_cast<uint64_t>(internDynamicString(lhs + rhs));
  }
  if (std::strcmp(s, "stringByAppendingString:") == 0) {
    std::string lhs = looksLikeReadablePointer(self) ? reinterpret_cast<const char*>(self) : "";
    std::string rhs = looksLikeReadablePointer(a0) ? reinterpret_cast<const char*>(a0) : "";
    return reinterpret_cast<uint64_t>(internDynamicString(lhs + rhs));
  }
  if (std::strcmp(s, "bundlePath") == 0 || std::strcmp(s, "resourcePath") == 0) {
    return reinterpret_cast<uint64_t>(guestNSHomeDirectory());
  }
  if (std::strcmp(s, "fileExistsAtPath:") == 0 ||
      std::strcmp(s, "fileExistsAtPath:isDirectory:") == 0) {
    if (!looksLikeReadablePointer(a0)) return 0;
    std::string hostPath = resolveSandboxHostPath(reinterpret_cast<const char*>(a0));
    struct stat st{};
    if (::stat(hostPath.c_str(), &st) != 0) return 0;
    if (std::strcmp(s, "fileExistsAtPath:isDirectory:") == 0 && looksLikeReadablePointer(a1)) {
      *reinterpret_cast<uint8_t*>(a1) = S_ISDIR(st.st_mode) ? 1 : 0;
    }
    return 1;
  }
  if (std::strcmp(s, "createDirectoryAtPath:withIntermediateDirectories:attributes:error:") == 0) {
    if (!looksLikeReadablePointer(a0)) return 0;
    std::string hostPath = resolveSandboxHostPath(reinterpret_cast<const char*>(a0));
    std::error_code ec;
    std::filesystem::create_directories(hostPath, ec);
    return (!ec || std::filesystem::is_directory(hostPath, ec)) ? 1 : 0;
  }

  return self;
}

int uiApplicationMainShim(int argc, char** argv, const void* principal, const void* delegate) {
  (void)argc; (void)argv; (void)principal; (void)delegate;
  ensureSandboxDirectories();
  noteCompatCall("UIApplicationMain");
  appendGuestOutput("[radeki-stub] UIApplicationMain(...) -- no UIKit backend; reporting a "
                    "completed startup loop (exit 0)\n");
  return 0;  // the guest's main() treats this as "app exited normally"
}

void nsLogShim(const void* format, ...) {
  char buf[64];
  std::snprintf(buf, sizeof buf, "[radeki-stub] NSLog(fmt=%p) -- format not parsed\n", format);
  noteCompatCall("NSLog");
  appendGuestOutput(buf);
}

[[noreturn]] void objcExceptionThrowShim(uint64_t exception) {
  char buf[96];
  std::snprintf(buf, sizeof buf, "guest Objective-C exception at %p",
                reinterpret_cast<void*>(exception));
  abortGuest(134, buf);
}

// --- OpenGL ES 2.0 -> Android EGL/GLESv2 forwarding wrappers -------------------------------
// When an Android EGL/GLESv2 context is current, calls forward directly into libGLESv2.so.
// When no hardware context is bound (or on a headless test host), safe GLESv2 state responses
// are returned so engine initialization (shader compilation, buffer generation, glGetString)
// never dereferences a null pointer or loops on GL errors.

std::atomic<uint32_t> g_nextGlObjectId{1};

const uint8_t* glGetStringShim(uint32_t name) {
  noteCompatCall("glGetString");
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = const uint8_t* (*)(uint32_t);
    static auto realFn = reinterpret_cast<Fn>(ng.resolveGl("glGetString"));
    if (realFn) {
      if (const uint8_t* s = realFn(name)) return s;
    }
  }
  switch (name) {
    case 0x1F00: return reinterpret_cast<const uint8_t*>("RadekiOSNative");                  // GL_VENDOR
    case 0x1F01: return reinterpret_cast<const uint8_t*>("RadekiOSNative EGL/GLESv2 Bridge"); // GL_RENDERER
    case 0x1F02: return reinterpret_cast<const uint8_t*>("OpenGL ES 2.0 RadekiOSNative");     // GL_VERSION
    case 0x8B8C: return reinterpret_cast<const uint8_t*>("OpenGL ES GLSL ES 1.00");           // GL_SHADING_LANGUAGE_VERSION
    case 0x1F03: return reinterpret_cast<const uint8_t*>("GL_OES_vertex_array_object GL_OES_mapbuffer GL_OES_depth24 GL_OES_rgb8_rgba8 GL_EXT_discard_framebuffer GL_APPLE_framebuffer_multisample"); // GL_EXTENSIONS
    default: return reinterpret_cast<const uint8_t*>("");
  }
}

uint32_t glGetErrorShim() {
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = uint32_t (*)();
    static auto realFn = reinterpret_cast<Fn>(ng.resolveGl("glGetError"));
    if (realFn) return realFn();
  }
  return 0;  // GL_NO_ERROR
}

uint32_t glCheckFramebufferStatusShim(uint32_t target) {
  noteCompatCall("glCheckFramebufferStatus");
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = uint32_t (*)(uint32_t);
    static auto realFn = reinterpret_cast<Fn>(ng.resolveGl("glCheckFramebufferStatus"));
    if (realFn) {
      uint32_t st = realFn(target);
      if (st != 0) return st;
    }
  }
  return 0x8CD5;  // GL_FRAMEBUFFER_COMPLETE
}

void glGenObjectsHelper(const char* glSym, int n, uint32_t* ids) {
  if (n <= 0 || !ids) return;
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = void (*)(int, uint32_t*);
    if (auto realFn = reinterpret_cast<Fn>(ng.resolveGl(glSym))) {
      ids[0] = 0;
      realFn(n, ids);
      if (ids[0] != 0) return;
    }
  }
  for (int i = 0; i < n; ++i) {
    ids[i] = g_nextGlObjectId.fetch_add(1, std::memory_order_relaxed);
  }
}

void glGenBuffersShim(int n, uint32_t* buffers) { noteCompatCall("glGenBuffers"); glGenObjectsHelper("glGenBuffers", n, buffers); }
void glGenTexturesShim(int n, uint32_t* textures) { noteCompatCall("glGenTextures"); glGenObjectsHelper("glGenTextures", n, textures); }
void glGenFramebuffersShim(int n, uint32_t* framebuffers) { noteCompatCall("glGenFramebuffers"); glGenObjectsHelper("glGenFramebuffers", n, framebuffers); }
void glGenRenderbuffersShim(int n, uint32_t* renderbuffers) { noteCompatCall("glGenRenderbuffers"); glGenObjectsHelper("glGenRenderbuffers", n, renderbuffers); }
void glGenVertexArraysOESShim(int n, uint32_t* arrays) { noteCompatCall("glGenVertexArraysOES"); glGenObjectsHelper("glGenVertexArraysOES", n, arrays); }

uint32_t glCreateShaderShim(uint32_t type) {
  noteCompatCall("glCreateShader");
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = uint32_t (*)(uint32_t);
    static auto realFn = reinterpret_cast<Fn>(ng.resolveGl("glCreateShader"));
    if (realFn) {
      if (uint32_t id = realFn(type)) return id;
    }
  }
  return g_nextGlObjectId.fetch_add(1, std::memory_order_relaxed);
}

uint32_t glCreateProgramShim() {
  noteCompatCall("glCreateProgram");
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = uint32_t (*)();
    static auto realFn = reinterpret_cast<Fn>(ng.resolveGl("glCreateProgram"));
    if (realFn) {
      if (uint32_t id = realFn()) return id;
    }
  }
  return g_nextGlObjectId.fetch_add(1, std::memory_order_relaxed);
}

void glGetShaderivShim(uint32_t shader, uint32_t pname, int32_t* params) {
  if (!params) return;
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = void (*)(uint32_t, uint32_t, int32_t*);
    static auto realFn = reinterpret_cast<Fn>(ng.resolveGl("glGetShaderiv"));
    if (realFn) {
      realFn(shader, pname, params);
      return;
    }
  }
  // GL_COMPILE_STATUS (0x8B81) -> GL_TRUE (1); GL_INFO_LOG_LENGTH (0x8B84) -> 0
  *params = (pname == 0x8B84) ? 0 : 1;
}

void glGetProgramivShim(uint32_t program, uint32_t pname, int32_t* params) {
  if (!params) return;
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = void (*)(uint32_t, uint32_t, int32_t*);
    static auto realFn = reinterpret_cast<Fn>(ng.resolveGl("glGetProgramiv"));
    if (realFn) {
      realFn(program, pname, params);
      return;
    }
  }
  // GL_LINK_STATUS (0x8B82) / GL_VALIDATE_STATUS (0x8B83) -> GL_TRUE (1); GL_INFO_LOG_LENGTH -> 0
  *params = (pname == 0x8B84) ? 0 : 1;
}

void glGetIntegervShim(uint32_t pname, int32_t* params) {
  if (!params) return;
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = void (*)(uint32_t, int32_t*);
    static auto realFn = reinterpret_cast<Fn>(ng.resolveGl("glGetIntegerv"));
    if (realFn) {
      realFn(pname, params);
      return;
    }
  }
  switch (pname) {
    case 0x0D33: *params = 4096; break;  // GL_MAX_TEXTURE_SIZE
    case 0x8869: *params = 16; break;    // GL_MAX_VERTEX_ATTRIBS
    case 0x8DFB: *params = 256; break;   // GL_MAX_VERTEX_UNIFORM_VECTORS
    case 0x8DFD: *params = 256; break;   // GL_MAX_FRAGMENT_UNIFORM_VECTORS
    case 0x8B4D: *params = 16; break;    // GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS
    case 0x8872: *params = 16; break;    // GL_MAX_TEXTURE_IMAGE_UNITS
    case 0x84E8: *params = 4096; break;  // GL_MAX_RENDERBUFFER_SIZE
    case 0x0BA2:                         // GL_VIEWPORT
      params[0] = 0; params[1] = 0; params[2] = g_surfaceWidth; params[3] = g_surfaceHeight;
      break;
    default: *params = 0; break;
  }
}

void glClearColorShim(float r, float g, float b, float a) {
  noteCompatCall("glClearColor");
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = void (*)(float, float, float, float);
    static auto realFn = reinterpret_cast<Fn>(ng.resolveGl("glClearColor"));
    if (realFn) realFn(r, g, b, a);
  }
}

void glClearShim(uint32_t mask) {
  noteCompatCall("glClear");
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = void (*)(uint32_t);
    static auto realFn = reinterpret_cast<Fn>(ng.resolveGl("glClear"));
    if (realFn) realFn(mask);
  }
}

void glViewportShim(int x, int y, int w, int h) {
  noteCompatCall("glViewport");
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = void (*)(int, int, int, int);
    static auto realFn = reinterpret_cast<Fn>(ng.resolveGl("glViewport"));
    if (realFn) realFn(x, y, w, h);
  }
}

void glDrawArraysShim(uint32_t mode, int first, int count) {
  noteCompatCall("glDrawArrays");
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = void (*)(uint32_t, int, int);
    static auto realFn = reinterpret_cast<Fn>(ng.resolveGl("glDrawArrays"));
    if (realFn) realFn(mode, first, count);
  }
}

void glDrawElementsShim(uint32_t mode, int count, uint32_t type, const void* indices) {
  noteCompatCall("glDrawElements");
  NativeGles& ng = nativeGles();
  if (ng.hasCurrentHardwareContext()) {
    using Fn = void (*)(uint32_t, int, uint32_t, const void*);
    static auto realFn = reinterpret_cast<Fn>(ng.resolveGl("glDrawElements"));
    if (realFn) realFn(mode, count, type, indices);
  }
}

using Fn = uint64_t;
void addShim(relinker::CompatRegistry& reg, const char* name, Fn fn, const char* fw) {
  reg.add(name, fn, {compat::SymbolClass::CompatibilityShim, fw, "shim"});
  ++g_count;
}

void addGlesEntry(relinker::CompatRegistry& reg, const char* machoName, uint64_t fallbackFn) {
  const char* elfName = (machoName[0] == '_') ? (machoName + 1) : machoName;
  void* resolved = nativeGles().resolveGl(elfName);
  // Use the explicit shim if provided, or the direct libGLESv2 symbol if resolved on device,
  // or the fallback no-op shim.
  uint64_t target = fallbackFn ? fallbackFn : (resolved ? reinterpret_cast<uint64_t>(resolved) : reinterpret_cast<Fn>(voidShim));
  reg.add(machoName, target, {compat::SymbolClass::AndroidBackend, "OpenGLES", "gles2_forward"});
  ++g_count;
  ++g_glesCount;
}

// DummyFrameworkClass instances keep stable addresses for the process lifetime.
DummyFrameworkClass& classStub(const char* name) {
  static auto& all = *new std::vector<DummyFrameworkClass*>();
  for (auto* c : all)
    if (std::strcmp(c->name, name) == 0) return *c;
  auto* c = new DummyFrameworkClass();
  std::snprintf(c->name, sizeof c->name, "%s", name);
  all.push_back(c);
  return *c;
}

void addClassPair(relinker::CompatRegistry& reg, const char* cls, const char* fw) {
  auto& stub = classStub(cls);
  uint64_t addr = reinterpret_cast<uint64_t>(&stub);
  reg.add(std::string("_OBJC_CLASS_$_") + cls, addr, {compat::SymbolClass::NoopStub, fw, "dummy_class"});
  reg.add(std::string("_OBJC_METACLASS_$_") + cls, addr, {compat::SymbolClass::NoopStub, fw, "dummy_class"});
  g_count += 2;
}

void addData(relinker::CompatRegistry& reg, const char* name, const char* fw, const char* label) {
  static auto& blocks = *new std::vector<DummyFrameworkClass*>();  // see classStub()
  auto* b = new DummyFrameworkClass();
  std::snprintf(b->name, sizeof b->name, "%s", label);
  blocks.push_back(b);
  reg.add(name, reinterpret_cast<uint64_t>(b), {compat::SymbolClass::NoopStub, fw, "dummy_data"});
  ++g_count;
}

}  // namespace

void registerFrameworkStubs(relinker::CompatRegistry& reg) {
  using namespace compat;

  // --- libobjc runtime family (selector-aware objc_msgSend + retain/release family) --------
  addShim(reg, "_objc_msgSend", reinterpret_cast<Fn>(objcMsgSendShim), "libobjc");
  for (const char* n : {"_objc_msgSendSuper", "_objc_msgSendSuper2",
                        "_objc_msgSend_stret", "_objc_retain", "_objc_retainBlock",
                        "_objc_retainAutorelease", "_objc_autorelease",
                        "_objc_autoreleaseReturnValue", "_objc_retainAutoreleasedReturnValue",
                        "_objc_unsafeClaimAutoreleasedReturnValue", "_objc_loadWeakRetained",
                        "_objc_rootRetain", "_CFRetain"})
    addShim(reg, n, reinterpret_cast<Fn>(passthrough), "libobjc");
  for (const char* n : {"_objc_release", "_objc_storeStrong", "_objc_storeWeak",
                        "_objc_destroyWeak", "_objc_clear_deallocating", "_objc_setProperty",
                        "_objc_setProperty_nonatomic", "_objc_copyWeak", "_objc_moveWeak",
                        "_objc_autoreleasePoolPop"})
    addShim(reg, n, reinterpret_cast<Fn>(voidShim1), "libobjc");
  addShim(reg, "_objc_autoreleasePoolPush", reinterpret_cast<Fn>(poolPushShim), "libobjc");
  for (const char* n : {"_sel_registerName", "_sel_getUid"})
    addShim(reg, n, reinterpret_cast<Fn>(passthrough), "libobjc");
  addShim(reg, "_sel_getName", reinterpret_cast<Fn>(emptyStringShim), "libobjc");
  for (const char* n : {"_objc_getClass", "_objc_lookUpClass", "_objc_getMetaClass",
                        "_objc_getRequiredClass", "_objc_getAssociatedObject",
                        "_class_isMetaClass", "_class_respondsToSelector", "_object_getClass"})
    addShim(reg, n, reinterpret_cast<Fn>(zeroShim), "libobjc");
  addShim(reg, "_objc_setAssociatedObject", reinterpret_cast<Fn>(voidShim2), "libobjc");
  addShim(reg, "_objc_exception_throw", reinterpret_cast<Fn>(objcExceptionThrowShim), "libobjc");

  // --- CoreFoundation ----------------------------------------------------------------------
  addShim(reg, "_CFRelease", reinterpret_cast<Fn>(voidShim1), "CoreFoundation");
  for (const char* n : {"_CFGetTypeID", "_CFStringGetLength", "_CFStringCreateWithCString",
                        "_CFStringCreateMutable", "_CFBundleGetMainBundle", "_CFRunLoopGetCurrent",
                        "_CFRunLoopRunInMode", "_CFPreferencesCopyAppValue", "_CFShow"})
    addShim(reg, n, reinterpret_cast<Fn>(zeroShim), "CoreFoundation");
  addShim(reg, "_CFRunLoopRun", reinterpret_cast<Fn>(voidShim), "CoreFoundation");
  addShim(reg, "_CFRunLoopStop", reinterpret_cast<Fn>(voidShim1), "CoreFoundation");
  addShim(reg, "_CFAbsoluteTimeGetCurrent", reinterpret_cast<Fn>(zeroDoubleShim), "CoreFoundation");

  // --- UIKit --------------------------------------------------------------------------------
  addShim(reg, "_UIApplicationMain", reinterpret_cast<Fn>(uiApplicationMainShim), "UIKit");
  for (const char* n : {"_UIGraphicsGetCurrentContext", "_UIGraphicsGetImageFromCurrentImageContext",
                        "_UIImagePNGRepresentation", "_UIImageJPEGRepresentation"})
    addShim(reg, n, reinterpret_cast<Fn>(zeroShim), "UIKit");
  for (const char* n : {"_UIGraphicsBeginImageContext", "_UIGraphicsEndImageContext",
                        "_UIImageWriteToSavedPhotosAlbum"})
    addShim(reg, n, reinterpret_cast<Fn>(voidShim), "UIKit");
  addShim(reg, "_UIGraphicsBeginImageContextWithOptions", reinterpret_cast<Fn>(voidShim), "UIKit");

  // --- Foundation (with sandboxed NSHomeDirectory / NSSearchPathForDirectoriesInDomains) ---
  addShim(reg, "_NSLog", reinterpret_cast<Fn>(nsLogShim), "Foundation");
  addShim(reg, "_NSHomeDirectory", reinterpret_cast<Fn>(guestNSHomeDirectory), "Foundation");
  addShim(reg, "_NSTemporaryDirectory", reinterpret_cast<Fn>(guestNSTemporaryDirectory), "Foundation");
  addShim(reg, "_NSSearchPathForDirectoriesInDomains",
          reinterpret_cast<Fn>(guestNSSearchPathForDirectoriesInDomains), "Foundation");
  for (const char* n : {"_NSUserName", "_NSFullUserName",
                        "_NSGetUncaughtExceptionHandler", "_NSClassFromString"})
    addShim(reg, n, reinterpret_cast<Fn>(zeroShim), "Foundation");
  addShim(reg, "_NSStringFromClass", reinterpret_cast<Fn>(emptyStringShim), "Foundation");
  addShim(reg, "_NSSetUncaughtExceptionHandler", reinterpret_cast<Fn>(voidShim1), "Foundation");

  // --- QuartzCore ---------------------------------------------------------------------------
  addShim(reg, "_CACurrentMediaTime", reinterpret_cast<Fn>(zeroDoubleShim), "QuartzCore");

  // --- EAGL C-level entrypoints & helpers ---------------------------------------------------
  addShim(reg, "_EAGLGetCurrentContext", reinterpret_cast<Fn>(eaglGetCurrentContext), "OpenGLES");
  addShim(reg, "_EAGLSetCurrentContext", reinterpret_cast<Fn>(eaglSetCurrentContext), "OpenGLES");

  // --- OpenGL ES 2.0 -> Android EGL/GLESv2 forwarding table --------------------------------
  addGlesEntry(reg, "_glGetString", reinterpret_cast<Fn>(glGetStringShim));
  addGlesEntry(reg, "_glGetError", reinterpret_cast<Fn>(glGetErrorShim));
  addGlesEntry(reg, "_glCheckFramebufferStatus", reinterpret_cast<Fn>(glCheckFramebufferStatusShim));
  addGlesEntry(reg, "_glGenBuffers", reinterpret_cast<Fn>(glGenBuffersShim));
  addGlesEntry(reg, "_glGenTextures", reinterpret_cast<Fn>(glGenTexturesShim));
  addGlesEntry(reg, "_glGenFramebuffers", reinterpret_cast<Fn>(glGenFramebuffersShim));
  addGlesEntry(reg, "_glGenRenderbuffers", reinterpret_cast<Fn>(glGenRenderbuffersShim));
  addGlesEntry(reg, "_glGenVertexArraysOES", reinterpret_cast<Fn>(glGenVertexArraysOESShim));
  addGlesEntry(reg, "_glCreateShader", reinterpret_cast<Fn>(glCreateShaderShim));
  addGlesEntry(reg, "_glCreateProgram", reinterpret_cast<Fn>(glCreateProgramShim));
  addGlesEntry(reg, "_glGetShaderiv", reinterpret_cast<Fn>(glGetShaderivShim));
  addGlesEntry(reg, "_glGetProgramiv", reinterpret_cast<Fn>(glGetProgramivShim));
  addGlesEntry(reg, "_glGetIntegerv", reinterpret_cast<Fn>(glGetIntegervShim));
  addGlesEntry(reg, "_glClearColor", reinterpret_cast<Fn>(glClearColorShim));
  addGlesEntry(reg, "_glClear", reinterpret_cast<Fn>(glClearShim));
  addGlesEntry(reg, "_glViewport", reinterpret_cast<Fn>(glViewportShim));
  addGlesEntry(reg, "_glDrawArrays", reinterpret_cast<Fn>(glDrawArraysShim));
  addGlesEntry(reg, "_glDrawElements", reinterpret_cast<Fn>(glDrawElementsShim));

  // Remaining OpenGL ES 2.0 standard entry points forwarded directly to Android's libGLESv2.so
  const char* gles2Functions[] = {
      "_glActiveTexture", "_glAttachShader", "_glBindAttribLocation", "_glBindBuffer",
      "_glBindFramebuffer", "_glBindRenderbuffer", "_glBindTexture", "_glBindVertexArrayOES",
      "_glBlendColor", "_glBlendEquation", "_glBlendEquationSeparate", "_glBlendFunc",
      "_glBlendFuncSeparate", "_glBufferData", "_glBufferSubData", "_glClearDepthf",
      "_glClearStencil", "_glColorMask", "_glCompileShader", "_glCompressedTexImage2D",
      "_glCompressedTexSubImage2D", "_glCopyTexImage2D", "_glCopyTexSubImage2D", "_glCullFace",
      "_glDeleteBuffers", "_glDeleteFramebuffers", "_glDeleteProgram", "_glDeleteRenderbuffers",
      "_glDeleteShader", "_glDeleteTextures", "_glDeleteVertexArraysOES", "_glDepthFunc",
      "_glDepthMask", "_glDepthRangef", "_glDetachShader", "_glDisable",
      "_glDisableVertexAttribArray", "_glDiscardFramebufferEXT", "_glEnable",
      "_glEnableVertexAttribArray", "_glFinish", "_glFlush", "_glFramebufferRenderbuffer",
      "_glFramebufferTexture2D", "_glFrontFace", "_glGenerateMipmap", "_glGetActiveAttrib",
      "_glGetActiveUniform", "_glGetAttachedShaders", "_glGetAttribLocation", "_glGetBooleanv",
      "_glGetBufferParameteriv", "_glGetFloatv", "_glGetFramebufferAttachmentParameteriv",
      "_glGetProgramInfoLog", "_glGetRenderbufferParameteriv", "_glGetShaderInfoLog",
      "_glGetShaderPrecisionFormat", "_glGetShaderSource", "_glGetTexParameterfv",
      "_glGetTexParameteriv", "_glGetUniformfv", "_glGetUniformiv", "_glGetUniformLocation",
      "_glGetVertexAttribfv", "_glGetVertexAttribiv", "_glGetVertexAttribPointerv", "_glHint",
      "_glIsBuffer", "_glIsEnabled", "_glIsFramebuffer", "_glIsProgram", "_glIsRenderbuffer",
      "_glIsShader", "_glIsTexture", "_glIsVertexArrayOES", "_glLineWidth", "_glLinkProgram",
      "_glMapBufferOES", "_glPixelStorei", "_glPolygonOffset", "_glReadPixels",
      "_glReleaseShaderCompiler", "_glRenderbufferStorage",
      "_glRenderbufferStorageMultisampleAPPLE", "_glResolveMultisampleFramebufferAPPLE",
      "_glSampleCoverage", "_glScissor", "_glShaderBinary", "_glShaderSource", "_glStencilFunc",
      "_glStencilFuncSeparate", "_glStencilMask", "_glStencilMaskSeparate", "_glStencilOp",
      "_glStencilOpSeparate", "_glTexImage2D", "_glTexParameterf", "_glTexParameterfv",
      "_glTexParameteri", "_glTexParameteriv", "_glTexSubImage2D", "_glUniform1f",
      "_glUniform1fv", "_glUniform1i", "_glUniform1iv", "_glUniform2f", "_glUniform2fv",
      "_glUniform2i", "_glUniform2iv", "_glUniform3f", "_glUniform3fv", "_glUniform3i",
      "_glUniform3iv", "_glUniform4f", "_glUniform4fv", "_glUniform4i", "_glUniform4iv",
      "_glUniformMatrix2fv", "_glUniformMatrix3fv", "_glUniformMatrix4fv", "_glUnmapBufferOES",
      "_glUseProgram", "_glValidateProgram", "_glVertexAttrib1f", "_glVertexAttrib1fv",
      "_glVertexAttrib2f", "_glVertexAttrib2fv", "_glVertexAttrib3f", "_glVertexAttrib3fv",
      "_glVertexAttrib4f", "_glVertexAttrib4fv", "_glVertexAttribPointer",
  };
  for (const char* glFn : gles2Functions) addGlesEntry(reg, glFn, 0);

  // --- dummy classes: the essential UIKit / EAGL / QuartzCore / Foundation set --------------
  const char* foundationClasses[] = {
      "NSObject", "NSProxy", "NSAutoreleasePool", "NSBundle", "NSString", "NSMutableString",
      "NSArray", "NSMutableArray", "NSDictionary", "NSMutableDictionary", "NSSet", "NSMutableSet",
      "NSNumber", "NSData", "NSMutableData", "NSDate", "NSError", "NSException", "NSValue",
      "NSNull", "NSURL", "NSThread", "NSTimer", "NSNotification", "NSNotificationCenter",
      "NSOperationQueue", "NSRunLoop", "NSUserDefaults", "NSFileManager", "NSLocale",
      "NSIndexPath", "NSProcessInfo", "NSUUID", "NSCache",
  };
  for (const char* c : foundationClasses) addClassPair(reg, c, "Foundation");
  const char* uikitClasses[] = {
      "UIResponder", "UIApplication", "UIScreen", "UIView", "UIViewController",
      "UINavigationController", "UITabBarController", "UIImagePickerController", "UIImage",
      "UIImageView", "UILabel", "UIButton", "UIControl", "UIColor", "UIFont", "UIEvent",
      "UITouch", "UIGestureRecognizer", "UITapGestureRecognizer", "UIPanGestureRecognizer",
      "UIScrollView", "UITableView", "UITableViewCell", "UITextField", "UITextView",
      "UIActivityIndicatorView", "UIAlertView", "UIActionSheet", "UIDevice", "UIBezierPath",
      "UIWebView",
  };
  for (const char* c : uikitClasses) addClassPair(reg, c, "UIKit");
  const char* quartzClasses[] = {"CALayer", "CAEAGLLayer", "CAAnimation", "CABasicAnimation"};
  for (const char* c : quartzClasses) addClassPair(reg, c, "QuartzCore");

  // EAGL + UIWindow + CADisplayLink + UIApplication get specialized dummy wrappers.
  reg.add("_OBJC_CLASS_$_EAGLContext", reinterpret_cast<uint64_t>(&g_dummyEAGLContext.classStub),
          {SymbolClass::NoopStub, "OpenGLES", "dummy_class"});
  reg.add("_OBJC_METACLASS_$_EAGLContext", reinterpret_cast<uint64_t>(&g_dummyEAGLContext.classStub),
          {SymbolClass::NoopStub, "OpenGLES", "dummy_class"});
  reg.add("_OBJC_CLASS_$_EAGLSharegroup", reinterpret_cast<uint64_t>(&g_dummyEAGLSharegroup.classStub),
          {SymbolClass::NoopStub, "OpenGLES", "dummy_class"});
  reg.add("_OBJC_METACLASS_$_EAGLSharegroup", reinterpret_cast<uint64_t>(&g_dummyEAGLSharegroup.classStub),
          {SymbolClass::NoopStub, "OpenGLES", "dummy_class"});
  reg.add("_OBJC_CLASS_$_UIWindow", reinterpret_cast<uint64_t>(&g_dummyUIWindow.classStub),
          {SymbolClass::NoopStub, "UIKit", "dummy_class"});
  reg.add("_OBJC_METACLASS_$_UIWindow", reinterpret_cast<uint64_t>(&g_dummyUIWindow.classStub),
          {SymbolClass::NoopStub, "UIKit", "dummy_class"});
  reg.add("_OBJC_CLASS_$_CADisplayLink", reinterpret_cast<uint64_t>(&g_dummyCADisplayLink.classStub),
          {SymbolClass::NoopStub, "QuartzCore", "dummy_class"});
  reg.add("_OBJC_METACLASS_$_CADisplayLink", reinterpret_cast<uint64_t>(&g_dummyCADisplayLink.classStub),
          {SymbolClass::NoopStub, "QuartzCore", "dummy_class"});
  std::snprintf(g_dummyEAGLContext.classStub.name, sizeof g_dummyEAGLContext.classStub.name, "EAGLContext");
  std::snprintf(g_dummyEAGLSharegroup.classStub.name, sizeof g_dummyEAGLSharegroup.classStub.name, "EAGLSharegroup");
  std::snprintf(g_dummyUIApplication.classStub.name, sizeof g_dummyUIApplication.classStub.name, "UIApplication");
  std::snprintf(g_dummyUIWindow.classStub.name, sizeof g_dummyUIWindow.classStub.name, "UIWindow");
  std::snprintf(g_dummyCADisplayLink.classStub.name, sizeof g_dummyCADisplayLink.classStub.name, "CADisplayLink");
  g_count += 8;

  const char* avClasses[] = {"AVAudioPlayer", "AVAudioSession", "AVPlayer"};
  for (const char* c : avClasses) addClassPair(reg, c, "AVFoundation");
  const char* skClasses[] = {"SKPaymentQueue", "SKPayment", "SKPaymentTransaction",
                             "SKProductsRequest", "SKProduct"};
  for (const char* c : skClasses) addClassPair(reg, c, "StoreKit");
  addClassPair(reg, "ASIdentifierManager", "AdSupport");

  // --- data constants the startup & EAGL code references ------------------------------------
  for (const char* n : {"_NSConcreteStackBlock", "_NSConcreteGlobalBlock", "_NSConcreteMallocBlock"})
    addData(reg, n, "libSystem", "NSConcreteBlock");
  for (const char* n : {"_kCFAllocatorDefault", "_kCFAllocatorMalloc", "_kCFAllocatorNull",
                        "_kCFAllocatorSystemDefault", "_kCFRunLoopDefaultMode",
                        "_kCFRunLoopCommonModes"})
    addData(reg, n, "CoreFoundation", n + 4);
  for (const char* n : {"_kEAGLDrawablePropertyRetainedBacking", "_kEAGLDrawablePropertyColorFormat",
                        "_kEAGLColorFormatRGBA8", "_kEAGLColorFormatRGB565"})
    addData(reg, n, "OpenGLES", n + 1);
  addData(reg, "_NSFoundationVersionNumber", "Foundation", "NSFoundationVersionNumber");
  for (const char* n : {"_UIWindowLevelNormal", "_UIWindowLevelAlert"})
    addData(reg, n, "UIKit", n + 1);
  for (const char* n : {"_UIApplicationDidFinishLaunchingNotification",
                        "_UIApplicationWillResignActiveNotification",
                        "_UIApplicationDidEnterBackgroundNotification",
                        "_UIApplicationWillEnterForegroundNotification",
                        "_UIApplicationDidBecomeActiveNotification",
                        "_UIKeyboardWillShowNotification", "_UIKeyboardDidShowNotification",
                        "_UIKeyboardWillHideNotification", "_UIKeyboardDidHideNotification"})
    addData(reg, n, "UIKit", n + 1);
}

size_t frameworkStubCount() { return g_count; }
size_t glesBridgeSymbolCount() { return g_glesCount; }

}  // namespace radeki::runtime
