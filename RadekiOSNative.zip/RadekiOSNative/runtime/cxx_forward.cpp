// Explicit libc++ forwarding wrappers. See cxx_forward.h for the doctrine.
//
// Every basic_string wrapper below implements the documented libc++ 64-bit storage layout
// explicitly (24 bytes: short mode holds size<<1 in byte 0 and up to 22 chars inline; long
// mode holds (capacity<<1)|1 in word 0, size in word 1 and the data pointer in word 2).
// They never reinterpret the host's std::string, because the host may be libstdc++, whose
// layout differs; on an Android NDK host the layouts agree anyway.
#include "runtime/cxx_forward.h"
#include "runtime/runtime.h"

#include <dlfcn.h>

#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <unordered_map>
#include <vector>

namespace radeki::runtime {
namespace {

constexpr size_t kSSOCapacity = 22;  // libc++ char SSO capacity on 64-bit little-endian

// Apple's ABI, written out. A GuestStdString* is exactly what the guest passes as `this`.
struct GuestStdString {
  uint64_t w[3];

  bool isLong() const { return (w[0] & 1) != 0; }
  size_t size() const { return isLong() ? size_t(w[1]) : size_t((w[0] & 0xFF) >> 1); }
  size_t capacity() const { return isLong() ? size_t(w[0] >> 1) : kSSOCapacity; }
  char* data() { return isLong() ? reinterpret_cast<char*>(w[2]) : reinterpret_cast<char*>(this) + 1; }
  const char* data() const { return const_cast<GuestStdString*>(this)->data(); }

  void makeShort(const char* p, size_t n) {
    char* d = reinterpret_cast<char*>(this);
    std::memset(this, 0, sizeof *this);
    d[0] = static_cast<char>(n << 1);  // LSB clear == short mode
    if (n) std::memcpy(d + 1, p, n);
    d[1 + n] = 0;
  }
  bool makeLong(const char* p, size_t n, size_t cap) {
    char* buf = static_cast<char*>(std::malloc(cap + 1));
    if (!buf) return false;  // OOM: caller degrades to empty rather than aborting the host
    if (n) std::memcpy(buf, p, n);
    buf[n] = 0;
    w[0] = (uint64_t(cap) << 1) | 1;
    w[1] = n;
    w[2] = reinterpret_cast<uint64_t>(buf);
    return true;
  }
  void releaseLong() {
    if (isLong()) std::free(reinterpret_cast<void*>(w[2]));
  }
};
static_assert(sizeof(GuestStdString) == 24, "libc++ basic_string<char> is 24 bytes on arm64");

// __init semantics: initialize raw storage. Short input stays inline; long input gets a fresh
// allocation with capacity == size (libc++'s __init allocates exactly n+1).
void gsInit(GuestStdString* s, const char* p, size_t n) {
  if (!p) { p = ""; n = 0; }  // defensive: a null C string becomes the empty string
  if (n <= kSSOCapacity) { s->makeShort(p, n); return; }
  if (!s->makeLong(p, n, n)) { s->makeShort("", 0); noteCompatCall("cxx_oom"); }
}

void gsFill(GuestStdString* s, size_t n, char c) {
  if (n <= kSSOCapacity) {
    char tmp[kSSOCapacity];
    std::memset(tmp, c, n);
    s->makeShort(tmp, n);
    return;
  }
  char* buf = static_cast<char*>(std::malloc(n + 1));
  if (!buf) { s->makeShort("", 0); noteCompatCall("cxx_oom"); return; }
  std::memset(buf, c, n);
  buf[n] = 0;
  s->w[0] = (uint64_t(n) << 1) | 1;
  s->w[1] = n;
  s->w[2] = reinterpret_cast<uint64_t>(buf);
}

void gsDestroy(GuestStdString* s) {
  s->releaseLong();
  std::memset(s, 0, sizeof *s);
}

// Grow policy for append/insert: at least the required size, else roughly doubling.
size_t gsNextCapacity(size_t current, size_t required) {
  size_t cap = required;
  if (current >= kSSOCapacity) cap = std::max(cap, 2 * current + 1);
  else cap = std::max(cap, 2 * (kSSOCapacity + 1));
  return cap;
}

void gsSetSize(GuestStdString* s, size_t n) {
  if (s->isLong()) s->w[1] = n;
  else reinterpret_cast<char*>(s)[0] = static_cast<char>(n << 1);
}

// Insertion with libc++'s allocation policy: storage only ever GROWS. A long string never
// collapses back to SSO, so a data() pointer the guest kept around stays valid exactly as
// long as real libc++ would keep it valid.
void gsReplace(GuestStdString* s, size_t pos, const char* p, size_t n) {
  if (!p) { p = ""; n = 0; }
  size_t sz = s->size();
  if (pos > sz) pos = sz;  // libc++ would throw out_of_range; exceptions are unsupported
  size_t tail = sz - pos;
  size_t newSize = pos + n + tail;
  if (newSize <= s->capacity()) {
    char* cur = s->data();
    std::memmove(cur + pos + n, cur + pos, tail);
    if (n) std::memcpy(cur + pos, p, n);
    cur[newSize] = 0;
    gsSetSize(s, newSize);
    return;
  }
  size_t cap = gsNextCapacity(s->capacity(), newSize);
  char* buf = static_cast<char*>(std::malloc(cap + 1));
  if (!buf) { noteCompatCall("cxx_oom"); return; }  // keep the old contents
  char* cur = s->data();
  std::memcpy(buf, cur, pos);
  std::memcpy(buf + pos, p, n);
  std::memcpy(buf + pos + n, cur + pos, tail);
  buf[newSize] = 0;
  s->releaseLong();
  s->w[0] = (uint64_t(cap) << 1) | 1;
  s->w[1] = newSize;
  s->w[2] = reinterpret_cast<uint64_t>(buf);
}

// Replace-all (assign) semantics: overwrite [0, size) with p[0, n), reusing storage when it
// fits and growing (never shrinking) otherwise.
void gsAssign(GuestStdString* s, const char* p, size_t n) {
  if (!p) { p = ""; n = 0; }
  if (n <= s->capacity()) {
    char* d = s->data();
    if (n) std::memmove(d, p, n);
    d[n] = 0;
    gsSetSize(s, n);
    return;
  }
  size_t cap = std::max(n, gsNextCapacity(s->capacity(), n));
  char* buf = static_cast<char*>(std::malloc(cap + 1));
  if (!buf) { noteCompatCall("cxx_oom"); return; }
  if (n) std::memcpy(buf, p, n);
  buf[n] = 0;
  s->releaseLong();
  s->w[0] = (uint64_t(cap) << 1) | 1;
  s->w[1] = n;
  s->w[2] = reinterpret_cast<uint64_t>(buf);
}

// --- wrappers with neutral names; the forwarding table registers them under Apple's ---------
// extern "C" linkage is unnecessary: the guest calls by address, never by host symbol name.

// std::__1::basic_string<char>::__init(const char*, size_type)
void w_init_ptr_len(GuestStdString* s, const char* p, uint64_t n) {
  noteCompatCall("std::string::__init(const char*,size)");
  gsInit(s, p, size_t(n));
}
// std::__1::basic_string<char>::__init(size_type, char)
void w_init_fill(GuestStdString* s, uint64_t n, char c) {
  noteCompatCall("std::string::__init(size,char)");
  gsFill(s, size_t(n), c);
}
// default constructors C1/C2: SSO-empty storage
void w_ctor_default(GuestStdString* s) {
  noteCompatCall("std::string::ctor()");
  s->makeShort("", 0);
}
// constructors from a C string, with and without the (ignored) allocator argument
void w_ctor_cstr(GuestStdString* s, const char* p) {
  noteCompatCall("std::string::ctor(const char*)");
  gsInit(s, p, p ? std::strlen(p) : 0);
}
void w_ctor_cstr_alloc(GuestStdString* s, const char* p, const void* /*alloc*/) {
  w_ctor_cstr(s, p);
}
// copy constructors C1/C2
void w_ctor_copy(GuestStdString* s, const GuestStdString* other) {
  noteCompatCall("std::string::ctor(const string&)");
  if (other) gsInit(s, other->data(), other->size());
  else s->makeShort("", 0);
}
// destructors D1/D2
void w_dtor(GuestStdString* s) {
  noteCompatCall("std::string::dtor()");
  gsDestroy(s);
}
// operator=(const basic_string&)
void w_assign_copy(GuestStdString* s, const GuestStdString* other) {
  noteCompatCall("std::string::operator=(const string&)");
  if (!other) { gsAssign(s, "", 0); return; }
  if (s == other) return;
  gsAssign(s, other->data(), other->size());
}
// assign(const char*, size_type)
void w_assign_ptr_len(GuestStdString* s, const char* p, uint64_t n) {
  noteCompatCall("std::string::assign(const char*,size)");
  gsAssign(s, p, size_t(n));
}
// assign(size_type, char)
void w_assign_fill(GuestStdString* s, uint64_t n, char c) {
  noteCompatCall("std::string::assign(size,char)");
  if (size_t(n) <= s->capacity()) {
    char* d = s->data();
    std::memset(d, c, size_t(n));
    d[n] = 0;
    gsSetSize(s, size_t(n));
    return;
  }
  s->releaseLong();
  gsFill(s, size_t(n), c);
}
// append(const char*, size_type)
void w_append_ptr_len(GuestStdString* s, const char* p, uint64_t n) {
  noteCompatCall("std::string::append(const char*,size)");
  gsReplace(s, s->size(), p, size_t(n));
}
// append(const basic_string&)
void w_append_str(GuestStdString* s, const GuestStdString* other) {
  noteCompatCall("std::string::append(const string&)");
  if (!other) return;
  gsReplace(s, s->size(), other->data(), other->size());
}
// push_back(char)
void w_push_back(GuestStdString* s, char c) {
  noteCompatCall("std::string::push_back");
  gsReplace(s, s->size(), &c, 1);
}
// reserve(size_type): libc++ only grows here; reserve(n) with n <= capacity() is a no-op
// (it never collapses long storage back to SSO, keeping data() pointers stable).
void w_reserve(GuestStdString* s, uint64_t n) {
  noteCompatCall("std::string::reserve");
  if (n <= s->capacity()) return;
  size_t sz = s->size();
  char* buf = static_cast<char*>(std::malloc(size_t(n) + 1));
  if (!buf) { noteCompatCall("cxx_oom"); return; }
  std::memcpy(buf, s->data(), sz);
  buf[sz] = 0;
  s->releaseLong();
  s->w[0] = (uint64_t(n) << 1) | 1;
  s->w[1] = sz;
  s->w[2] = reinterpret_cast<uint64_t>(buf);
}
// resize(size_type, char) and resize(size_type)
void w_resize_fill(GuestStdString* s, uint64_t n, char c) {
  noteCompatCall("std::string::resize");
  size_t sz = s->size();
  if (size_t(n) <= sz) {  // truncate in place; capacity is preserved, like libc++
    char* d = s->data();
    d[n] = 0;
    gsSetSize(s, size_t(n));
    return;
  }
  size_t extra = size_t(n) - sz;
  if (size_t(n) <= s->capacity()) {  // fits the existing storage (SSO or long)
    char* d = s->data();
    std::memset(d + sz, c, extra);
    d[n] = 0;
    gsSetSize(s, size_t(n));
    return;
  }
  std::vector<char> fill(extra, c);
  gsReplace(s, sz, fill.data(), extra);
}
void w_resize(GuestStdString* s, uint64_t n) { w_resize_fill(s, n, 0); }
// insert(size_type, const char*, size_type)
void w_insert_ptr_len(GuestStdString* s, uint64_t pos, const char* p, uint64_t n) {
  noteCompatCall("std::string::insert");
  gsReplace(s, size_t(pos), p, size_t(n));
}
// compare(const char*) const
int w_compare_cstr(const GuestStdString* s, const char* rhs) {
  noteCompatCall("std::string::compare(const char*)");
  if (!rhs) rhs = "";
  size_t sz = s ? s->size() : 0;
  const char* lhs = s ? s->data() : "";
  size_t rl = std::strlen(rhs);
  size_t n = std::min(sz, rl);
  int c = n ? std::memcmp(lhs, rhs, n) : 0;
  if (c) return c;
  return sz < rl ? -1 : (sz > rl ? 1 : 0);
}

// std::__1::ios_base::Init -- the classic C++ static-init dependency. Its only job is to
// exist so __GLOBAL__I_* constructors complete; iostream formatting itself reaches us only
// through the stub dispatcher.
void w_ios_init_ctor(void* /*self*/) { noteCompatCall("std::ios_base::Init::Init"); }
void w_ios_init_dtor(void* /*self*/) { noteCompatCall("std::ios_base::Init::~Init"); }

template <class F> uint64_t fn(F* f) { return reinterpret_cast<uint64_t>(f); }

// basic_string data symbol: std::string::npos lives in the dylib on iOS.
const uint64_t kGuestNpos = ~uint64_t(0);

constexpr const char* S = "__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE";

}  // namespace

const std::vector<CxxForwardEntry>& cxxForwardTable() {
  static const std::vector<CxxForwardEntry> real = [] {
    std::vector<CxxForwardEntry> t;
    auto add = [&](const std::string& m, uint64_t impl, const char* what, bool data = false) {
      t.push_back({m, impl, what, data});
    };
    add(std::string(S) + "6__initEPKcm", fn(w_init_ptr_len), "std::string::__init(const char*, size_type)");
    add(std::string(S) + "6__initEmc", fn(w_init_fill), "std::string::__init(size_type, char)");
    add(std::string(S) + "C1Ev", fn(w_ctor_default), "std::string::string()");
    add(std::string(S) + "C2Ev", fn(w_ctor_default), "std::string::string() [base]");
    add(std::string(S) + "C1EPKc", fn(w_ctor_cstr), "std::string::string(const char*)");
    add(std::string(S) + "C2EPKc", fn(w_ctor_cstr), "std::string::string(const char*) [base]");
    add(std::string(S) + "C1EPKcRKS4_", fn(w_ctor_cstr_alloc), "std::string::string(const char*, const allocator&)");
    add(std::string(S) + "C1ERKS5_", fn(w_ctor_copy), "std::string::string(const string&)");
    add(std::string(S) + "C2ERKS5_", fn(w_ctor_copy), "std::string::string(const string&) [base]");
    add(std::string(S) + "D1Ev", fn(w_dtor), "std::string::~string()");
    add(std::string(S) + "D2Ev", fn(w_dtor), "std::string::~string() [base]");
    add(std::string(S) + "aSERKS5_", fn(w_assign_copy), "std::string::operator=(const string&)");
    add(std::string(S) + "6assignEPKcm", fn(w_assign_ptr_len), "std::string::assign(const char*, size_type)");
    add(std::string(S) + "6assignEmc", fn(w_assign_fill), "std::string::assign(size_type, char)");
    add(std::string(S) + "6appendEPKcm", fn(w_append_ptr_len), "std::string::append(const char*, size_type)");
    add(std::string(S) + "6appendERKS5_", fn(w_append_str), "std::string::append(const string&)");
    add(std::string(S) + "9push_backEc", fn(w_push_back), "std::string::push_back(char)");
    add(std::string(S) + "7reserveEm", fn(w_reserve), "std::string::reserve(size_type)");
    add(std::string(S) + "6resizeEm", fn(w_resize), "std::string::resize(size_type)");
    add(std::string(S) + "6resizeEmc", fn(w_resize_fill), "std::string::resize(size_type, char)");
    add(std::string(S) + "6insertEmPKcm", fn(w_insert_ptr_len), "std::string::insert(size_type, const char*, size_type)");
    add(std::string(S) + "6compareEPKc", fn(w_compare_cstr), "std::string::compare(const char*)");
    add(std::string(S) + "4nposE", reinterpret_cast<uint64_t>(&kGuestNpos), "std::string::npos", true);
    // ios_base::Init: required by any TU that touches <iostream> at static-init time.
    add("__ZNSt3__18ios_base4InitC1Ev", fn(w_ios_init_ctor), "std::ios_base::Init::Init()");
    add("__ZNSt3__18ios_base4InitC2Ev", fn(w_ios_init_ctor), "std::ios_base::Init::Init() [base]");
    add("__ZNSt3__18ios_base4InitD1Ev", fn(w_ios_init_dtor), "std::ios_base::Init::~Init()");
    add("__ZNSt3__18ios_base4InitD2Ev", fn(w_ios_init_dtor), "std::ios_base::Init::~Init() [base]");
    return t;
  }();
  return real;
}

std::optional<uint64_t> lookupCxxForward(const std::string& mangled) {
  for (const auto& e : cxxForwardTable())
    if (mangled == e.mangled) return e.impl;
  return std::nullopt;
}

void addCxxForwarding(relinker::CompatRegistry& reg) {
  for (const auto& e : cxxForwardTable())
    reg.add(e.mangled, e.impl, {compat::SymbolClass::AndroidBackend, "libc++",
                                 std::string("libc++_shared_forward: ") + e.what});
}

bool isAppleCxxDylib(const std::string& installName) {
  return installName.find("libc++") != std::string::npos ||
         installName.find("libc++abi") != std::string::npos;
}

// --- dlsym pass-through --------------------------------------------------------------------

struct HostCxxResolver::Cache {
  std::mutex mu;
  std::unordered_map<std::string, std::optional<uint64_t>> entries;
};

HostCxxResolver::Cache& HostCxxResolver::cache() {
  static Cache c;
  return c;
}

std::optional<uint64_t> HostCxxResolver::resolve(const std::string& symbol, const std::string& dylib) const {
  // Only C++ mangled names, and only when the IPA asked an Apple C++ dylib for them (or asked
  // flat). Android's libc++ uses the identical std::__1 mangling, so a hit is ABI-compatible.
  if (symbol.rfind("_Z", 0) != 0) return std::nullopt;
  if (!dylib.empty() && !isAppleCxxDylib(dylib)) return std::nullopt;
  Cache& c = cache();
  {
    std::lock_guard<std::mutex> lock(c.mu);
    auto it = c.entries.find(symbol);
    if (it != c.entries.end()) return it->second;
  }
  void* p = dlsym(RTLD_DEFAULT, symbol.c_str());
  std::optional<uint64_t> hit;
  if (p) hit = reinterpret_cast<uint64_t>(p);
  std::lock_guard<std::mutex> lock(c.mu);
  c.entries[symbol] = hit;
  return hit;
}

std::optional<compat::CompatEntry> HostCxxResolver::describe(const std::string& symbol, const std::string& dylib) const {
  if (!resolve(symbol, dylib)) return std::nullopt;
  return compat::CompatEntry{compat::SymbolClass::AndroidBackend, "libc++", "dlsym_forward"};
}

size_t HostCxxResolver::cachedHits() const {
  Cache& c = cache();
  std::lock_guard<std::mutex> lock(c.mu);
  size_t n = 0;
  for (const auto& kv : c.entries) n += kv.second.has_value();
  return n;
}

}  // namespace radeki::runtime
