// Minimal framework stub layer: the hand-written end of "unbound Mach-O imports do not trap".
//
// Three kinds of entries, all registered into a CompatRegistry by registerFrameworkStubs():
//
//  1. Written shims for symbols whose *call itself* matters for the startup loop: NSLog,
//     UIApplicationMain (returns 0 = "app launched"), the objc memory-management family
//     (retain/autorelease pass the object through instead of nil-ing it), sel_registerName,
//     autorelease pools, and a few CoreFoundation basics. These keep object graphs alive
//     long enough for static constructors and -[app init] chains to complete.
//
//  2. Dummy C++ structures backing _OBJC_CLASS_$_ / _OBJC_METACLASS_$_ data imports for the
//     essential UIKit, EAGL, QuartzCore and Foundation classes. A DummyFrameworkClass is
//     objc-class-shaped (isa/superclass/cache/vtable/data bits, all zero) with the class
//     name kept for diagnostics; there is no Objective-C runtime to dispatch through it, so
//     its job is to make __objc_classrefs slots point at something sane instead of trapping.
//
//  3. Data constants (_NSConcreteStackBlock, kCFAllocatorDefault, NSFoundationVersionNumber,
//     a few notification names) as labelled zeroed blocks.
//
// Everything the table does not name falls through to the dispatch stub factory
// (stub_dispatch.h), which handles the long tail generically and logs every first call.
// Nothing here pretends to implement a framework; capabilities.json says so too.
#pragma once
#include <cstdint>

#include "relinker/relinker.h"

namespace radeki::runtime {

// objc-class-shaped dummy backing store. All real fields zero; the label is diagnostic.
struct DummyFrameworkClass {
  uint64_t isa = 0;
  uint64_t superclass = 0;
  uint64_t cacheBuckets = 0;
  uint64_t cacheMaskVtable = 0;
  uint64_t dataBits = 0;  // class_data_bits_t: zero -> any real dereference faults visibly
  char name[24] = {};
};
static_assert(sizeof(DummyFrameworkClass) == 64, "dummy class stays one cache line");

// Dummy minimal wrappers for EAGL / UIApplication startup essentials. They exist so that
// code which *constructs* these objects (the common startup pattern) gets a valid-looking,
// zero-initialized object instead of a trap; method calls still go through the stub layer.
struct DummyEAGLSharegroup {
  DummyFrameworkClass classStub;
  uint32_t refcount = 1;
};
struct DummyEAGLContext {
  DummyFrameworkClass classStub;
  uint32_t api = 0;               // kEAGLRenderingAPI 0 = none
  uint64_t sharegroup = 0;        // set by the (stubbed) initWithAPI: path
  uint32_t multiThreaded = 0;
};
struct DummyUIApplication {
  DummyFrameworkClass classStub;
  uint64_t delegate = 0;
  uint32_t applicationState = 0;  // UIApplicationStateActive
  uint32_t idleTimerDisabled = 0;
};

// Registers every hand-written framework stub into `reg` with honest classifications:
// shims -> COMPATIBILITY_SHIM "shim", dummy classes/constants -> NOOP_STUB "dummy_class" /
// "dummy_data". Called by makeHostRuntime(); deliberately NOT part of makeCompatRegistry().
void registerFrameworkStubs(relinker::CompatRegistry& reg);
size_t frameworkStubCount();

}  // namespace radeki::runtime
