// Runtime: maps a relinked ARM64 image into this process and executes the ORIGINAL AArch64 code natively.
// Only works on an ARM64 host (Android arm64-v8a). On other hosts run() reports that clearly.
#pragma once
#include <string>
#include <vector>

#include "loader/dyld.h"
#include "mach_o/macho.h"
#include "relinker/relinker.h"

namespace radeki::runtime {

struct RunResult {
  bool ran = false;          // guest main returned or called exit/abort
  bool crashed = false;      // guest raised a fatal signal
  int exitCode = 0;
  std::string signalName, trapSymbol, error, output;
  uint64_t faultPc = 0, faultAddr = 0;
};

// Compatibility "libSystem" subset (non-variadic, ABI-identical functions only).
relinker::CompatRegistry makeCompatRegistry();
std::string takeGuestOutput();
void appendGuestOutput(const std::string& s);
[[noreturn]] void abortGuest(int code, const char* reason);  // unwinds out of guest code

RunResult run(const relinker::LinkedImage& li);
// Link (trying several load bases) and run an image with the compat registry.
RunResult runImage(const macho::Image& img);

// One entry per image handed to runLoadedImage(), in link order.
struct ImageRun {
  std::string path;
  bool ran = false;       // this image's entry point returned (or the process exited inside it)
  bool crashed = false;
  bool skipped = false;   // never started: an earlier image exited the process
  int exitCode = 0;
  std::string signalName, trapSymbol, error;
  uint64_t faultPc = 0, faultAddr = 0;
};

struct MultiRunResult {
  bool ran = false;        // the run reached the end of the image list without crashing
  bool crashed = false;
  int exitCode = 0;        // exit status of the image that ended the run
  std::string error, output;
  std::vector<ImageRun> images;
  bool ok() const { return error.empty() && !crashed; }
};

// Links every image in the registry (using `opt.fallback` as the last-resort resolver, i.e.
// the compat libSystem) and runs them inside ONE process: a single reservation covers every
// image, so their slides are what dyld would give them, and cross-image pointers resolve.
// Images are started in the registry's link order (dependencies before importers).
// Like run(), this needs an ARM64 host; elsewhere it reports why instead of pretending.
MultiRunResult runLoadedImage(loader::Registry& reg, const loader::Options& opt);

}  // namespace radeki::runtime
