// Runtime: maps a relinked ARM64 image into this process and executes the ORIGINAL AArch64 code natively.
// Only works on an ARM64 host (Android arm64-v8a). On other hosts run() reports that clearly.
#pragma once
#include <string>
#include <vector>

#include "mach_o/macho.h"
#include "relinker/relinker.h"

namespace radeki::runtime {

struct RunResult {
  bool ran = false;          // guest main returned or called exit/abort
  bool crashed = false;      // guest raised a fatal signal
  int exitCode = 0;
  std::string signalName, trapSymbol, error, output;
  uint64_t faultPc = 0, faultAddr = 0;
};

// Compatibility "libSystem" subset (non-variadic, ABI-identical functions only).
relinker::CompatRegistry makeCompatRegistry();
std::string takeGuestOutput();
void appendGuestOutput(const std::string& s);
[[noreturn]] void abortGuest(int code, const char* reason);  // unwinds out of guest code

RunResult run(const relinker::LinkedImage& li);
// Link (trying several load bases) and run an image with the compat registry.
RunResult runImage(const macho::Image& img);

}  // namespace radeki::runtime
