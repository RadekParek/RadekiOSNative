// Runtime: maps a relinked ARM64 image into this process and executes the ORIGINAL AArch64 code natively.
// Only works on an ARM64 host (Android arm64-v8a). On other hosts run() reports that clearly.
#pragma once
#include <string>
#include <vector>

#include "loader/dyld.h"
#include "mach_o/macho.h"
#include "relinker/relinker.h"

namespace radeki::runtime {

struct RunResult {
  bool ran = false;          // guest main returned or called exit/abort
  bool crashed = false;      // guest raised a fatal signal
  int exitCode = 0;
  std::string signalName, trapSymbol, error, output;
  uint64_t faultPc = 0, faultAddr = 0;
  std::string trapClass, subsystem, resolutionMethod, callSymbol, image;
  uint64_t callAddress = 0;
  int64_t threadId = 0;
  std::vector<std::string> recentCalls;
  size_t dispatchStubs = 0;  // imports bound to logging no-op stubs instead of traps
};

// Compatibility "libSystem" subset (non-variadic, ABI-identical functions only), the written
// libc++abi shims, and the libc++.1.dylib -> host C++ forwarding table. Framework dummy
// classes/stubs are NOT included here (see makeHostRuntime / registerFrameworkStubs).
relinker::CompatRegistry makeCompatRegistry();

// The complete host runtime layer handed to the loader as `Options::fallback`:
//   registry      = makeCompatRegistry() + framework shims + dummy UIKit/EAGL/Foundation objects
//   dlsym         = chained behind the registry: dlsym pass-through onto the host libc++
//   stubFactory   = logging no-op dispatch stubs for whatever remains unresolved
// Owns everything; keep it alive for the whole link+run cycle.
class HostCxxResolver;  // runtime/cxx_forward.h: dlsym pass-through onto the host libc++
struct HostRuntime {
  relinker::CompatRegistry registry;
  HostCxxResolver* dlsym = nullptr;  // owned; chained as registry.chainNext()
  relinker::StubFactory stubFactory;
  ~HostRuntime();
  HostRuntime() = default;
  HostRuntime(HostRuntime&&) noexcept;
  HostRuntime& operator=(HostRuntime&&) noexcept;
};
HostRuntime makeHostRuntime();

std::string describeResult(const RunResult&);
void noteCompatCall(const std::string&);
std::vector<std::string> recentCompatCalls();
void resetRecentCompatCalls();
std::string takeGuestOutput();
void appendGuestOutput(const std::string& s);
[[noreturn]] void abortGuest(int code, const char* reason);  // unwinds out of guest code

RunResult run(const relinker::LinkedImage& li);
// Link (trying several load bases) and run an image with the compat registry.
// useStubs=true additionally enables the host runtime layer: framework shims/dummies and the
// logging dispatch-stub factory, so unbound imports keep the startup loop alive instead of
// trapping (the run still reports them via RunResult::dispatchStubs).
RunResult runImage(const macho::Image& img, bool useStubs = false);

// One entry per image handed to runLoadedImage(), in link order.
struct ImageRun {
  std::string path;
  bool ran = false;       // this image's entry point returned (or the process exited inside it)
  bool crashed = false;
  bool skipped = false;   // never started: an earlier image exited the process
  int exitCode = 0;
  std::string signalName, trapSymbol, error;
  uint64_t faultPc = 0, faultAddr = 0;
};

struct MultiRunResult {
  bool ran = false;        // the run reached the end of the image list without crashing
  bool crashed = false;
  int exitCode = 0;        // exit status of the image that ended the run
  std::string error, output;
  std::vector<ImageRun> images;
  size_t dispatchStubs = 0;          // imports bound to logging no-op stubs instead of traps
  std::vector<std::string> stubbed;  // their names (capped), for reports
  bool ok() const { return error.empty() && !crashed; }
};

// Links every image in the registry (using `opt.fallback` as the last-resort resolver, i.e.
// the compat libSystem) and runs them inside ONE process: a single reservation covers every
// image, so their slides are what dyld would give them, and cross-image pointers resolve.
// Images are started in the registry's link order (dependencies before importers).
// Like run(), this needs an ARM64 host; elsewhere it reports why instead of pretending.
MultiRunResult runLoadedImage(loader::Registry& reg, const loader::Options& opt);

}  // namespace radeki::runtime
