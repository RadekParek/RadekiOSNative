#pragma once
#include <string>
namespace radeki::compat {
enum class SymbolClass { Unsupported, HostDirect, CompatibilityShim, AndroidBackend, IOSFramework, WeakOptional, GuestImage };
inline const char* symbolClassName(SymbolClass c) {
  switch (c) {
    case SymbolClass::Unsupported: return "UNSUPPORTED";
    case SymbolClass::HostDirect: return "HOST_DIRECT";
    case SymbolClass::CompatibilityShim: return "COMPATIBILITY_SHIM";
    case SymbolClass::AndroidBackend: return "ANDROID_BACKEND";
    case SymbolClass::IOSFramework: return "IOS_FRAMEWORK";
    case SymbolClass::WeakOptional: return "WEAK_OPTIONAL";
    case SymbolClass::GuestImage: return "GUEST_IMAGE";
  }
  return "UNSUPPORTED";
}
struct CompatEntry { SymbolClass cls = SymbolClass::Unsupported; std::string framework, method; };
}
