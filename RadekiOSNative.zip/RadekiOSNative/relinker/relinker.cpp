#include "relinker/relinker.h"

#include <algorithm>
#include <cstring>

#include "arm64/arm64.h"
#include "core/bytes.h"

namespace radeki::relinker {
using namespace macho;

uint32_t LinkedImage::read32(uint64_t a) const {
  if (!contains(a, 4)) throw LinkError("read32 outside image");
  uint32_t v; std::memcpy(&v, memory.data() + (a - loadBase), 4); return v;
}
uint64_t LinkedImage::read64(uint64_t a) const {
  if (!contains(a, 8)) throw LinkError("read64 outside image");
  uint64_t v; std::memcpy(&v, memory.data() + (a - loadBase), 8); return v;
}
void LinkedImage::write32(uint64_t a, uint32_t v) {
  if (!contains(a, 4)) throw LinkError("write32 outside image");
  std::memcpy(memory.data() + (a - loadBase), &v, 4);
}

LinkedImage link(const Image& img, const LinkOptions& opt) {
  if (img.arch != Arch::ARM64 && img.arch != Arch::ARM64e) throw LinkError(std::string("unsupported architecture for native relink: ") + archName(img.arch));
  if (img.cryptId) throw LinkError("image is encrypted (cryptid != 0); refusing to link encrypted segments");
  if (img.filetype != MH_EXECUTE && img.filetype != MH_DYLIB) throw LinkError("unsupported Mach-O filetype");
  if (opt.loadBase % kPageSize) throw LinkError("loadBase must be 16K aligned");
  for (const auto& f : img.fixups)
    if (f.auth) throw LinkError("arm64e authenticated pointer fixups require the PAC layer (not implemented)");

  uint64_t minVm = UINT64_MAX, maxVm = 0;
  for (const auto& s : img.segments) {
    if (s.name == "__PAGEZERO" || s.vmsize == 0) continue;
    minVm = std::min(minVm, s.vmaddr);
    maxVm = std::max(maxVm, s.vmaddr + s.vmsize);
  }
  if (minVm == UINT64_MAX) throw LinkError("no mappable segments");
  if (minVm != img.textBase()) throw LinkError("header segment is not the lowest mapped segment");
  if (minVm % kPageSize) throw LinkError("image base not 16K aligned");
  uint64_t imageSize = alignUp(maxVm - minVm, kPageSize);
  if (imageSize > opt.maxImageBytes) throw LinkError("image too large");

  LinkedImage li;
  li.loadBase = opt.loadBase;
  li.imageBase = minVm;
  li.slide = opt.loadBase - minVm;
  li.imageSize = imageSize;
  if (opt.loadBase + imageSize + (16ull << 20) < opt.loadBase) throw LinkError("loadBase overflows address space");

  // Resolve imports first so the trap-stub area can be sized.
  struct Res { bool ok; uint64_t target; int trap; };
  std::vector<Res> res(img.imports.size(), {false, 0, -1});
  uint32_t trapCount = 0;
  std::vector<std::string> dylibOf(img.imports.size());
  for (size_t i = 0; i < img.imports.size(); ++i) {
    const Import& im = img.imports[i];
    if (im.libOrdinal >= 1 && size_t(im.libOrdinal) <= img.dylibs.size()) {
      // ordinals count only non-ID dylib commands
      int n = 0;
      for (const auto& d : img.dylibs) if (d.kind != DylibKind::Id && ++n == im.libOrdinal) { dylibOf[i] = d.name; break; }
    }
    std::optional<uint64_t> t;
    if (opt.resolver) t = opt.resolver->resolve(im.name, dylibOf[i]);
    if (t) res[i] = {true, *t, -1};
    else if (!im.weak) res[i].trap = int(trapCount++);
  }

  uint64_t stubBytes = alignUp(uint64_t(trapCount) * 4, 16) + uint64_t(opt.veneerSlots) * 16;
  li.totalSize = imageSize + alignUp(std::max<uint64_t>(stubBytes, 16), kPageSize);
  li.memory.assign(li.totalSize, 0);

  for (const auto& s : img.segments) {
    if (s.name == "__PAGEZERO" || s.vmsize == 0) continue;
    if (s.filesize) std::memcpy(li.memory.data() + (s.vmaddr - minVm), img.data.data() + s.fileoff, s.filesize);
    li.regions.push_back({s.name, s.vmaddr + li.slide, alignUp(s.vmsize, kPageSize), s.initprot, (s.initprot & VM_PROT_EXECUTE) != 0});
    for (const auto& x : s.sections) li.warnings.reserve(0), (void)x;
  }
  uint64_t stubBase = li.loadBase + imageSize;
  li.regions.push_back({"__RADEKI_STUBS", stubBase, li.totalSize - imageSize, VM_PROT_READ | VM_PROT_EXECUTE, true});
  li.veneerBase = stubBase + alignUp(uint64_t(trapCount) * 4, 16);
  li.veneerCap = opt.veneerSlots;

  for (uint32_t t = 0; t < trapCount; ++t) {
    uint64_t addr = stubBase + uint64_t(t) * 4;
    li.write32(addr, 0xD4200000u | (t & 0xFFFF) << 5);  // BRK #t
  }
  if (trapCount > 0xFFFF) throw LinkError("too many unresolved imports");
  for (size_t i = 0; i < img.imports.size(); ++i)
    if (res[i].trap >= 0) {
      uint32_t t = uint32_t(res[i].trap);
      li.traps.push_back({t, stubBase + uint64_t(t) * 4, img.imports[i].name});
    }

  auto slotOff = [&](uint64_t vm, uint64_t n) {
    if (vm < minVm || vm - minVm + n > imageSize) throw LinkError("fixup location outside image");
    return vm - minVm;
  };
  for (const auto& f : img.fixups) {
    uint64_t o = slotOff(f.addr, 8);
    uint64_t v;
    if (f.kind == Fixup::Kind::Rebase) {
      if (f.target < minVm || f.target > maxVm) li.warnings.push_back("rebase target outside image at " + std::to_string(f.addr));
      v = (f.target + li.slide) | (uint64_t(f.high8) << 56);
      ++li.rebases;
    } else {
      const Import& im = img.imports.at(f.importIndex);
      const Res& r = res.at(f.importIndex);
      BoundImport b{im.name, dylibOf[f.importIndex], f.addr + li.slide, r.ok, im.weak, 0, r.trap};
      if (r.ok) v = r.target + uint64_t(f.addend), b.target = v;
      else if (r.trap >= 0) v = stubBase + uint64_t(r.trap) * 4, b.target = v;
      else v = 0;  // unresolved weak import binds to null, matching dyld semantics
      li.imports.push_back(std::move(b));
      ++li.binds;
    }
    std::memcpy(li.memory.data() + o, &v, 8);
  }
  if (img.entry) li.entry = *img.entry + li.slide;
  for (auto& d : img.dataInCode) li.dataInCode.push_back({d.first + li.slide, d.second});
  return li;
}

void patchBranch(LinkedImage& li, uint64_t site, uint64_t target, bool link) {
  bool inCode = false;
  for (const auto& r : li.regions) if (r.code && site >= r.addr && site + 4 <= r.addr + r.size) inCode = true;
  if (!inCode || (site & 3)) throw LinkError("branch site is not in executable memory");
  if (auto w = a64::encodeB(site, target, link)) { li.write32(site, *w); return; }
  if (li.veneerCount >= li.veneerCap) throw LinkError("veneer pool exhausted");
  uint64_t v = li.veneerBase + li.veneerCount++ * 16;
  li.write32(v, 0x58000050);      // LDR x16, #8
  li.write32(v + 4, 0xD61F0200);  // BR x16
  uint64_t o = v - li.loadBase + 8;
  std::memcpy(li.memory.data() + o, &target, 8);
  auto w = a64::encodeB(site, v, link);
  if (!w) throw LinkError("veneer out of branch range");
  li.write32(site, *w);
}

Validation validate(const LinkedImage& li) {
  Validation out;
  auto inData = [&](uint64_t a) {
    for (auto& d : li.dataInCode) if (a >= d.first && a < d.first + d.second) return true;
    return false;
  };
  for (const auto& r : li.regions) {
    if (!r.code) continue;
    // The veneer pool holds 8-byte literals; only its used part contains instructions.
    uint64_t end = r.addr + r.size;
    if (r.name == "__RADEKI_STUBS") end = li.veneerBase;
    for (uint64_t a = r.addr; a + 4 <= end; a += 4) {
      if (inData(a)) continue;
      a64::Insn i = a64::decode(li.read32(a));
      if (!i.pcRel()) continue;
      ++out.checked;
      uint64_t t = a64::targetOf(i, a);
      if (li.contains(t)) continue;
      Violation v{a, "pc-relative reference to 0x" + std::to_string(t) + " leaves the image"};
      if (i.kind == a64::Kind::ADRP) out.warnings.push_back(v); else out.violations.push_back(v);
    }
  }
  return out;
}

}  // namespace radeki::relinker
