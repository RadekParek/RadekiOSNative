# RadekiOSNative (early foundation)
Native-first iOS -> Android ARM64 compatibility platform. Original AArch64 code is relinked, not emulated.

## What works (tested on host, 103 checks, ASan/UBSan clean)
- Mach-O: thin/fat, 32/64-bit, load commands, symbols, dyld-info rebase/bind, chained fixups (PTR_64, PTR_64_OFFSET, arm64e formats parsed), function starts, data-in-code, encryption info; hostile input rejected (mutation fuzz test).
- Analyzer: functions, call/branch/ADRP xrefs, PAC instruction counts, framework/ObjC/Swift/Metal/GLES hints, static blockers.
- ARM64 relinker: slide to new base, rebase, bind to compat registry, unresolved imports become named BRK trap stubs (never fake success), B/BL veneers, reference validator.
- Verification: a test-only mini AArch64 interpreter runs a relinked synthetic image and checks output.

## Not done (see progress.json / capabilities.json)
Android runtime/APK, native execution on device, ARM64e PAC, ARMv7 AOT, ObjC/Foundation/UIKit, Metal/GLES/Vulkan, audio, input.
Encrypted (FairPlay) binaries are refused; the tool does not decrypt anything.

## Build
`make` / `make test` / `make SAN=1 test`; CLI: `build/radeki analyze|convert|validate <macho> [--json] [-o dir] [--load-base 0x..]`
