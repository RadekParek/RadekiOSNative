# RadekiOSNative (early foundation)
Native-first iOS -> Android ARM64 compatibility platform. Original AArch64 code is relinked, not emulated.

## What works (tested on host, 213 checks, ASan/UBSan clean)
- Mach-O: thin/fat, 32/64-bit, load commands, symbols, dyld-info rebase/bind, chained fixups (PTR_64, PTR_64_OFFSET, arm64e formats parsed), function starts, data-in-code, encryption info; hostile input rejected (mutation fuzz test).
- Analyzer: functions, call/branch/ADRP xrefs, PAC instruction counts, framework/ObjC/Swift/Metal/GLES hints, static blockers.
- Objective-C metadata (read-only): class objects -> `class_ro_t`, instance and class methods (both the classic absolute-pointer and the relative 12-byte encodings), ivars, properties, categories, protocols. It never throws on hostile metadata: anything it cannot verify is reported as a warning and flips `complete` to false. This is metadata reading, **not** a runtime: nothing is registered, dispatched or called.
- ARM64 relinker: slide to new base, rebase, bind to compat registry, unresolved imports become named BRK trap stubs (never fake success), B/BL veneers, reference validator.
- Validation: every PC-relative reference is checked against the mapped image. It walks real instruction ranges (sections marked `S_ATTR_*_INSTRUCTIONS`, plus trap stubs and veneers), so Mach-O headers, load commands and string constants are not mistaken for code.
- Loader (`loader/dyld.*`): several images in one address space -- dependency-first link order, per-image load bases and slides, cross-image binding (two-level, re-export chains, flat-namespace), per-image unresolved-import reporting. Two passes: the first fixes the layout, the second binds against the complete export table.
- Runtime: maps a relinked image (or a whole linked image set) into this process, W^X, signal-safe call into guest code, and a libSystem subset (stdio/string/malloc/libm, `_exit`, `_abort`, a static non-recursive pthread subset).
- Verification: a test-only mini AArch64 interpreter runs a relinked synthetic image and checks output; cross-image binding is verified structurally (bound pointers land inside the provider image, no trap stubs left).

## Not done (see progress.json / capabilities.json)
Execution on a device (the runtime has never run on real ARM64 hardware -- only compiled here), ARM64e PAC, ARMv7 AOT, an Objective-C runtime (message dispatch, class registration, `NSObject`), Foundation/UIKit, CoreFoundation/CoreGraphics/QuartzCore, Metal/GLES/Vulkan, audio, input, networking, filesystem.
The loader has no dyld shared cache, no `@rpath`/`@executable_path` expansion against a filesystem, no cross-image initializer ordering and no weak-symbol coalescing. Encrypted (FairPlay) binaries are refused; the tool does not decrypt anything.

## Build
`make` / `make test` / `make SAN=1 test` (host), or CMake (`CMakeLists.txt`), or the Android app under `android/`.

CLI:
```
radeki analyze  <macho> [--json] [--objc]
radeki convert  <macho> [-o dir] [--load-base 0x..] [--json]
radeki validate <macho> [--load-base 0x..] [--json]
radeki load     <exe> [--dylib <path>]... [--load-base 0x..] [--json]
radeki run      <exe> [--dylib <path>]... [--load-base 0x..] [--json]   # needs an ARM64 host
```
Exit codes: 0 ok, 1 error, 2 usage, 3 = linked, but some imports had no provider (named trap stubs remain).

The changelog lives next to `RadekiOSNative.zip` in the repository root.
